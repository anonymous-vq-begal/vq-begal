import os
import gc
import json
import numpy as np
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.cuda.amp import autocast, GradScaler
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
from tqdm import tqdm
from .strategy import Strategy



def dice_coefficient(pred, target, epsilon=1e-6):
    pred = torch.sigmoid(pred)
    pred = pred.view(-1)
    target = target.view(-1)
    #     pred = (pred > 0.5).float()
    intersection = (pred * target).sum()
    #     print(pred.sum(),target.sum())
    return (2. * intersection + epsilon) / (pred.sum() + target.sum() + epsilon)

class CombinedLoss(nn.Module):
    def __init__(self, smooth=1):
        super().__init__()
        self.smooth = smooth
        self.bce = nn.BCEWithLogitsLoss()

    def forward(self, pred, target, epoch, total_epochs):
        progress = epoch / total_epochs
        # 使用更温和的权重变化
        if epoch < total_epochs // 3:
            # 早期阶段：BCE权重从0.8逐渐境地到0.6
            bce_weight = 0.8 - 0.2 * (epoch / (total_epochs // 3))
            dice_weight = 1 - bce_weight
        else:
            # 后期阶段： 更平缓的余弦退火
            current_alpha = 0.4 + 0.3 * (1 - math.cos(progress * math.pi)) / 2
            bce_weight = 1 - current_alpha
            dice_weight = current_alpha

        pred = torch.sigmoid(pred)
        intersection = (pred * target).sum()
        dice_loss = 1 - (2. * intersection + self.smooth) / (pred.sum() + target.sum() + self.smooth)
        bce_loss = self.bce(pred, target)

        # 添加权重平滑项
        weight_decay = 0.01 * (bce_weight ** 2 + dice_weight ** 2)

        return bce_weight * bce_loss + dice_weight * dice_loss + weight_decay


class RandomSampling(Strategy):
    def __init__(self, ct_data, mr_data, net, args):
        super(RandomSampling, self).__init__(ct_data, mr_data, net, args)

    def query(self, n):
        unlabeled_data_list = self.ct_data.get_unlabeled_data()
        incides = list(range(len(unlabeled_data_list)))
        np.random.shuffle(incides)
        # 随机分配为top和bottom组
        top_n_incides = incides[:n]
        bottom_n_incides = incides[n:2*n]

        top_n_original_indices = [unlabeled_data_list[i][1] for i in top_n_incides]
        bottom_n_original_indices = [unlabeled_data_list[i][1] for i in bottom_n_incides]

        return top_n_original_indices, bottom_n_original_indices


class Bio_EntropySampling(Strategy):
    def __init__(self, ct_data, mr_data, net, args):
        super(Bio_EntropySampling, self).__init__(ct_data, mr_data, net, args)
        self.n_mc_samples = 5  # 调整采样次数
        self.temperature = 1.5  # 调整预测置信度
        self.feature_weight = 0.4  # 调整特征空间权重
        self.uncertainty_weight = 0.6  # 调整不确定性权重

    def query(self, n):
        unlabeled_data_list = self.ct_data.get_unlabeled_data()
        unlabeled_mr_data_list = self.mr_data.get_unlabeled_data()
        print(f"未标记样本数量: {len(unlabeled_data_list)}")

        # 获取预测概率
        probs = self._monte_carlo_predict(unlabeled_data_list, unlabeled_mr_data_list)
        feature_scores = self._compute_feature_scores(unlabeled_data_list, unlabeled_mr_data_list)

        # 计算最终分数
        uncertainty_scores = self._compute_uncertainty_scores(probs)
        final_scores = self._combine_scores(uncertainty_scores, feature_scores)


        # 排序并选择样本
        sorted_incides_descending = torch.argsort(final_scores, descending=True)
        sorted_indices_ascending = torch.argsort(final_scores)

        top_n_indices = sorted_incides_descending[:n]
        bottom_n_indices = sorted_indices_ascending[:n]

        top_n_original_indices = [unlabeled_data_list[i][1] for i in top_n_indices]
        bottom_n_original_indices = [unlabeled_data_list[i][1] for i in bottom_n_indices]

        return top_n_original_indices, bottom_n_original_indices

class Net:
    def __init__(self, model, binary_model, device, args):
        self.model = model.to(device)
        self.binary_model = binary_model.to(device)
        self.device = device
        self.args = args


        self.criterion = SafeLoss(CombinedLoss())
        self.best_val_loss = float('inf')  # 记录全局最佳验证损失

        self.scaler = GradScaler(
            init_scale=2 ** 12,
            growth_factor=1.5,
            backoff_factor=0.7,
            growth_interval=500,
            enabled=True
        )

    def create_optimizer_and_scheduler(self, steps_per_epoch):
        # 计算训练步数和预热步数
        num_training_steps = self.args.num_epochs * steps_per_epoch
        num_warmup_steps = min(num_training_steps // 5, 2000)

        decoder_param_groups = [
            {'params': self.model.decoder.parameters(), 'lr': self.args.learning_rate * 1.5},
            {'params': self.model.fusion.parameters(), 'lr': self.args.learning_rate * 1.3}
        ]
        optimizer_de = optim.AdamW(
            decoder_param_groups,
            lr=self.args.learning_rate,
            weight_decay=0.001,
            betas=(0.9, 0.999),
            eps=1e-8,
            amsgrad=True
        )

        encoder_param_groups = [
            {'params': self.model.encoder.parameters(), 'lr': self.args.learning_rate * 1.1},
            {'params': self.model.adaptor.parameters(), 'lr': self.args.learning_rate * 1.2},
            {'params': self.model.vqvae.parameters(), 'lr': self.args.learning_rate * 1.2}
        ]
        optimizer_en = optim.AdamW(
            encoder_param_groups,
            lr=self.args.learning_rate,
            weight_decay=0.001,
            betas=(0.9, 0.999),
            eps=1e-8,
            amsgrad=True
        )

        def lr_lambda(current_step):
            if current_step < num_warmup_steps:
                return float(current_step) / float(max(1, num_warmup_steps))
            progress = float(current_step - num_warmup_steps) / float(
                max(1, num_training_steps - num_warmup_steps))
            return max(0.1, 0.5 * (1.0 + math.cos(math.pi * progress)))

        scheduler_de = torch.optim.lr_scheduler.LambdaLR(optimizer_de, lr_lambda)
        scheduler_en = torch.optim.lr_scheduler.LambdaLR(optimizer_en, lr_lambda)

        # 设置梯度裁剪
        for group in optimizer_de.param_groups + optimizer_en.param_groups:
            group['initial_lr'] = group['lr']
            group['max_grad_norm'] = 0.5

        return (optimizer_de, optimizer_en), (scheduler_de, scheduler_en)


    def _process_batch(self, batch, mr_batch, indices):
        inputs = batch['batch']['data'][indices].to(self.device).float()
        labels = batch['batch']['label'][indices].to(self.device).float()
        mr_inputs = mr_batch['batch']['data'][indices].to(self.device).float()
        weights = batch['batch']['weight'][indices].to(self.device).float()
        labels = torch.where(labels != 0, torch.tensor(1, dtype=labels.dtype).cuda(), labels)
        return inputs, labels, mr_inputs, weights



    def _compute_loss(self, outputs, labels, weights, vq_loss, vq_loss2, deep_loss1, deep_loss2, epoch):
        segmentation_loss = self.criterion(outputs, labels.float(), epoch, self.args.num_epochs)
        segmentation_loss = (segmentation_loss * weights.view(-1, 1, 1, 1)).mean()
        dice = dice_coefficient(outputs, labels)
        total_loss = 10 * segmentation_loss + 0.2 * (vq_loss + vq_loss2) + 0.1 * (deep_loss1 + deep_loss2)
        return total_loss, segmentation_loss, dice



    def bio_train(self, dataload, mr_dataload, valid_data_list, valid_mr_data_list, rd):
        """训练函数，集成了训练和验证过程"""
        print(f"\nStarting training for round {rd}")
        n_epoch = self.args.num_epochs
        self.model.train()

        # 记录当前round的训练历史
        round_history = {
            'round': rd,
            'epochs': [],
            'train_losses': [],
            'train_dice_scores': [],
            'valid_losses': [],
            'valid_dice_scores': [],
            'learning_rates': []
        }

        print(f"Length of dataload: {len(dataload)}")
        print(f"Length of mr_dataload: {len(mr_dataload)}")

        # 创建优化器和调度器
        self.optimizers, self.schedulers = self.create_optimizer_and_scheduler(len(dataload))
        optimizer_de, optimizer_en = self.optimizers
        scheduler_de, scheduler_en = self.schedulers

        # 创建验证数据加载器
        valid_dataload = DataLoader(valid_data_list, batch_size=4, shuffle=False, num_workers=4)
        mr_valid_dataload = DataLoader(valid_mr_data_list, batch_size=4, shuffle=False, num_workers=4)

        round_best_val_loss = float('inf')

        for epoch in tqdm(range(1, n_epoch + 1), ncols=100):
            # 训练阶段
            train_stats = self._train_epoch(epoch, dataload, mr_dataload,
                                            optimizer_de, optimizer_en, scheduler_de, scheduler_en)

            # 验证阶段
            val_stats = self._validate_epoch(epoch, valid_dataload, mr_valid_dataload)

            # 更新训练历史
            round_history['epochs'].append(epoch)
            round_history['train_losses'].append(train_stats['loss'])
            round_history['train_dice_scores'].append(train_stats['dice'])
            round_history['valid_losses'].append(val_stats['loss'])
            round_history['valid_dice_scores'].append(val_stats['dice'])
            round_history['learning_rates'].append(optimizer_de.param_groups[0]['lr'])

            # 打印当前epoch的统计信息
            print(f"\nEpoch [{epoch}/{n_epoch}]")
            print(f"Train Loss: {train_stats['loss']:.3f}, Train Dice: {train_stats['dice']:.3f}")
            print(f"Valid Loss: {val_stats['loss']:.3f}, Valid Dice: {val_stats['dice']:.3f}")

            # 保存全局最佳模型（跨所有round）
            if val_stats['loss'] < self.best_val_loss:
                self.best_val_loss = val_stats['loss']
                self._save_best_model(epoch, val_stats, rd)
                round_best_val_loss = val_stats['loss']

            # 清理内存
            gc.collect()
            torch.cuda.empty_cache()

        # 保存当前round的训练历史
        self._save_round_history(round_history)

        # 如果当前round是最佳round，绘制其训练曲线
        if round_best_val_loss == self.best_val_loss:
            self._plot_best_round_curves(round_history)

        return round_history

    def _train_epoch(self, epoch, dataload, mr_dataload, optimizer_de, optimizer_en, scheduler_de, scheduler_en):
        """执行一个训练epoch"""
        self.model.train()
        epoch_loss = 0
        epoch_dice = 0
        step = 0

        dataload_iterator = iter(dataload)
        mr_dataload_iterator = iter(mr_dataload)
        total_steps = len(dataload)

        for batch_idx in range(total_steps):
            try:
                batch = next(dataload_iterator)
                mr_batch = next(mr_dataload_iterator)

                if batch is not None:
                    step += 1
                    # 选择优化器
                    if batch['type'] == 'decoder':
                        optimizer = optimizer_de
                        scheduler = scheduler_de
                        indices = batch['decoder_idxs']
                    else:
                        optimizer = optimizer_en
                        scheduler = scheduler_en
                        indices = batch['encoder_idxs']

                    # 处理批次数据
                    inputs, labels, mr_inputs, weights = self._process_batch(batch, mr_batch, indices)

                    # 检查输入数据
                    if torch.isnan(inputs).any() or torch.isinf(inputs).any():
                        print(f"Warning: Found NaN or Inf in batch {batch_idx}")
                        continue

                    # 训练步骤
                    optimizer.zero_grad()
                    with autocast():
                        outputs_tuple, ct_encode_feature, mr_encode_feature, vq_loss, vq_loss2 = self.model(
                            inputs, mr_inputs)
                        outputs, deep_out1, deep_out2 = outputs_tuple
                        deep_loss1 = self.criterion(deep_out1, labels.float(), epoch, self.args.num_epochs)
                        deep_loss2 = self.criterion(deep_out2, labels.float(), epoch, self.args.num_epochs)

                        current_dice = dice_coefficient(outputs, labels)
                        total_loss, segmentation_loss, dice = self._compute_loss(
                            outputs, labels, weights, vq_loss, vq_loss2, deep_loss1, deep_loss2, epoch)

                    # 检查损失值
                    if not torch.isfinite(total_loss):
                        print(f"Warning: non-finite loss detected: {total_loss}")
                        continue

                    # 反向传播
                    self.scaler.scale(total_loss).backward()
                    self.scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), 0.5)
                    self.scaler.step(optimizer)
                    scheduler.step()
                    self.scaler.update()

                    epoch_loss += segmentation_loss.detach().item()
                    epoch_dice += current_dice.item()

                    if batch_idx % 10 == 0:
                        torch.cuda.empty_cache()

            except Exception as e:
                print(f"Error in batch {batch_idx}: {str(e)}")
                continue

        return {
            'loss': epoch_loss / step if step > 0 else 0,
            'dice': epoch_dice / step if step > 0 else 0
        }

    def _validate_epoch(self, epoch, valid_dataload, mr_valid_dataload):
        """执行一个验证epoch"""
        self.model.eval()
        val_loss = 0
        val_dice = 0
        step = 0

        with torch.no_grad():
            for (x, y), mr_x in zip(valid_dataload, mr_valid_dataload):
                step += 1
                inputs = x.to(self.device).float()
                labels = y.to(self.device).float()
                mr_inputs = mr_x.to(self.device).float()
                labels = torch.where(labels != 0, torch.tensor(1, dtype=labels.dtype).cuda(), labels)

                outputs, _, _, _, _ = self.model(inputs, mr_inputs)
                loss = self.criterion(outputs, labels, epoch, self.args.num_epochs)
                dice = dice_coefficient(outputs, labels)

                val_loss += loss.item()
                val_dice += dice.item()

        return {
            'loss': val_loss / step if step > 0 else 0,
            'dice': val_dice / step if step > 0 else 0
        }

    def _save_best_model(self, epoch, val_stats, rd):
        """保存全局最佳模型"""
        model_save_path = './model/active_learning/best_model_overall.pth'
        if os.path.exists(model_save_path):
            os.remove(model_save_path)

        torch.save({
            'model_state_dict': self.model.state_dict(),
            'optimizer_de_state_dict': self.optimizers[0].state_dict(),
            'optimizer_en_state_dict': self.optimizers[1].state_dict(),
            'scaler_state_dict': self.scaler.state_dict(),
            'round': rd,
            'epoch': epoch,
            'valid_loss': val_stats['loss'],
            'valid_dice': val_stats['dice']
        }, model_save_path)
        print(f"Saved new best model from round {rd}, epoch {epoch} with validation loss: {val_stats['loss']:.3f}")

    def _save_round_history(self, history):
        """保存每个round的训练历史"""
        os.makedirs('./results/active_learning', exist_ok=True)
        with open(f'./results/active_learning/training_history_round_{history["round"]}.json', 'w') as f:
            json.dump(history, f, indent=4)

    def _plot_best_round_curves(self, history):
        """只为最佳round绘制训练曲线"""
        plt.figure(figsize=(15, 5))

        # 损失曲线
        plt.subplot(1, 3, 1)
        plt.plot(history['epochs'], history['train_losses'], label='Training Loss')
        plt.plot(history['epochs'], history['valid_losses'], label='Validation Loss')
        plt.title(f'Loss Curves - Best Round {history["round"]}')
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.legend()

        # Dice分数曲线
        plt.subplot(1, 3, 2)
        plt.plot(history['epochs'], history['train_dice_scores'], label='Training Dice')
        plt.plot(history['epochs'], history['valid_dice_scores'], label='Validation Dice')
        plt.title(f'Dice Score Curves - Best Round {history["round"]}')
        plt.xlabel('Epoch')
        plt.ylabel('Dice Score')
        plt.legend()

        # 学习率曲线
        plt.subplot(1, 3, 3)
        plt.plot(history['epochs'], history['learning_rates'], label='Learning Rate')
        plt.title(f'Learning Rate - Best Round {history["round"]}')
        plt.xlabel('Epoch')
        plt.ylabel('Learning Rate')
        plt.legend()

        plt.tight_layout()
        os.makedirs('./results/active_learning', exist_ok=True)
        plt.savefig('./results/active_learning/best_round_training_curves.png')
        plt.close()

    def evaluate(self, test_data_list, mr_test_data_list):
        """测试集评估"""
        self.model.eval()
        test_dataload = DataLoader(test_data_list, batch_size=4, shuffle=False, num_workers=4)
        mr_test_dataload = DataLoader(mr_test_data_list, batch_size=4, shuffle=False, num_workers=4)

        test_loss = 0
        test_dice = 0
        step = 0

        try:
            with torch.no_grad():
                for (x, y), mr_x in zip(test_dataload, mr_test_dataload):
                    step += 1
                    inputs = x.to(self.device).float()
                    labels = y.to(self.device).float()
                    mr_inputs = mr_x.to(self.device).float()
                    labels = torch.where(labels != 0, torch.tensor(1, dtype=labels.dtype).cuda(), labels)

                    outputs, _, _, _, _ = self.model(inputs, mr_inputs)
                    loss = self.criterion(outputs, labels, self.args.num_epochs, self.args.num_epochs)
                    dice = dice_coefficient(outputs, labels)

                    test_loss += loss.item()
                    test_dice += dice.item()

        except Exception as e:
            print(f"Error during evaluation: {str(e)}")
            return None

        test_metrics = {
            'loss': test_loss / step if step > 0 else 0,
            'dice': test_dice / step if step > 0 else 0
        }

        self.model.train()
        return test_metrics


    def predict_prob(self, data_list, mr_data_list):
        self.model.eval()
        self.binary_model.eval()
        probs = torch.zeros([len(data_list), 2])

        # 修改数据加载器的创建方式
        dataloader = DataLoader(
            data_list,  # 直接使用完整的data_list
            batch_size=8,
            shuffle=False
        )
        mr_dataloader = DataLoader(
            mr_data_list,
            batch_size=8,
            shuffle=False
        )

        with torch.no_grad():
            batch_idx = 0
            for data, mr_data in zip(dataloader, mr_dataloader):
                # 正确解包数据
                x = data[0].to(self.device)  # 第一个元素是图像
                mr_x = mr_data[0].to(self.device)  # MR图像

                # 获取编码特征
                _, ct_encode_feature, _, _, _ = self.model(x, mr_x)

                # 获取logits并转换为概率
                logits = self.binary_model(ct_encode_feature)
                prob = F.softmax(logits, dim=1)

                # 更新probs
                batch_size = prob.size(0)
                probs[batch_idx:batch_idx + batch_size] = prob.cpu().clone().detach()
                batch_idx += batch_size

        return probs
