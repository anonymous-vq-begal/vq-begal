import numpy as np
import torch
from torchvision import datasets
from torch.utils.data import Dataset, DataLoader

class Data:
    def __init__(self, X_train, Y_train, X_val, Y_val, X_test, Y_test):
        self.X_train = X_train
        self.Y_train = Y_train
        self.X_val = X_val
        self.Y_val = Y_val
        self.X_test = X_test
        self.Y_test = Y_test

        self.n_pool = len(X_train)
        self.n_val = len(X_val)
        self.n_test = len(X_test)
        
        self.labeled_idxs = np.zeros(self.n_pool, dtype=int)   # 将所有数据的labeled_idxs初始化为0
        # 添加样本权重记录，初始化为1
        self.sample_weights = np.ones(self.n_pool, dtype=float)
        # 添加记录样本被选中轮次的数组
        self.selection_round = np.zeros(self.n_pool, dtype=int)
        # 添加最大轮次追踪
        self.max_rounds = 1

    def update_weights(self, current_round):
        # 更新最大轮次
        self.max_rounds = max(self.max_rounds, current_round)
        # 找出所有已被选中的样本
        selected_mask = self.selection_round > 0
        # 计算这些样本被训练的轮数
        rounds_trained = current_round - self.selection_round[selected_mask] + 1
        # 组合权重计算
        base_weights = 1.0 / np.sqrt(rounds_trained)
        round_importance = self.selection_round[selected_mask] / self.max_rounds
        self.sample_weights[selected_mask] = base_weights * (0.5 + 0.5 * round_importance)

        # 规范化权重到【0.1, 1.0】范围
        if len(self.sample_weights[selected_mask]) > 0:
            weights_min = self.sample_weights[selected_mask].min()
            weights_max = self.sample_weights[selected_mask].max()
            if weights_max > weights_min:
                self.sample_weights[selected_mask] = 0.1 + 0.9 * (self.sample_weights[selected_mask] - weights_min) / (weights_max - weights_min)

        # 打印权重更新信息
        if np.sum(selected_mask) > 0:
            print(f"更新的样本数量： {np.sum(selected_mask)}")
            print(f"权重范围: [{self.sample_weights[selected_mask].min():.4f}, {self.sample_weights[selected_mask].max():.4f}]")
            print(f"平均权重：{self.sample_weights[selected_mask].mean():.4f}")


    def get_unlabeled_data(self):
        unlabeled_idxs = np.arange(self.n_pool)[self.labeled_idxs == 0]
        unlabeled_data = self.X_train[unlabeled_idxs]

        return [(unlabeled_data[i], unlabeled_idxs[i]) for i in range(len(unlabeled_data))]

    def get_labeled_data(self):
        """获取已标记的训练数据"""
        # 获取标记为 2 或 3 的样本索引（分别代表 top 和 bottom 样本）
        labeled_idxs = np.arange(self.n_pool)[np.logical_or(self.labeled_idxs == 2, self.labeled_idxs == 3)]
        labeled_data = self.X_train[labeled_idxs]
        labeled_labels = self.Y_train[labeled_idxs]
        labeled_weights = self.sample_weights[labeled_idxs]
        # 返回数据对列表，包含数据和对应的标签
        return [(labeled_data[i], labeled_labels[i], labeled_weights[i]) for i in range(len(labeled_data))]
        
    def get_val_data(self):
        # val_idxs = np.arange(self.n_val)
        # val_data = self.X_val[val_idxs]
        # val_labels = self.Y_val[val_idxs]
        # 直接返回数据对，无需创建额外的索引
        return [(self.X_val[i], self.Y_val[i]) for i in range(len(self.X_val))]

    def get_test_data(self):
        return [(self.X_test[i], self.Y_test[i]) for i in range(len(self.X_test))]

    def get_labeled_size(self):
        """获取已标记样本数量"""
        return np.sum(self.labeled_idxs > 0)




class SelectDataset(Dataset):
    def __init__(self, data_object, current_round):
        self.X = data_object.X_train
        self.Y = data_object.Y_train
        self.labeled_idxs = data_object.labeled_idxs
        # 获取样本权重
        self.weights = data_object.sample_weights

        valid_idxs = np.where((self.labeled_idxs == 2) | (self.labeled_idxs == 3))[0]
        self.X = self.X[valid_idxs]
        self.Y = self.Y[valid_idxs]
        self.labeled_idxs = self.labeled_idxs[valid_idxs]
        # 获取对应的权重
        self.weights = self.weights[valid_idxs]
        # 归一化权重，以确保训练稳定（确保权重和为1）
        self.weights = self.weights / np.sum(self.weights) * len(self.weights)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return {'data': self.X[idx], 'label': self.Y[idx], 'labeled': self.labeled_idxs[idx], 'weight': self.weights[idx]}


class SelectBatchDataLoader(DataLoader):
    def __init__(self, dataset, batch_size=4, shuffle=False, **kwargs):
        super().__init__(dataset, batch_size=batch_size, shuffle=shuffle, **kwargs)

        def __len__(self):
            # 添加详细的长度计算打印
            n_samples = len(self.dataset)
            n_complete_batches = n_samples // self.batch_size
            has_incomplete_batch = n_samples % self.batch_size > 0
            total_batches = n_complete_batches + (1 if has_incomplete_batch else 0)
            print(f"Total samples: {n_samples}")
            print(f"Total batches: {total_batches}")
            return total_batches

    def __iter__(self):
        # 按顺序迭代所有批次
        batch_generator = super().__iter__()
        while True:
            batch = next(batch_generator)
            labeled = batch['labeled'].numpy()
            decoder_idxs = np.where(labeled == 2)[0]
            encoder_idxs = np.where(labeled == 3)[0]

            # 如果当前批次有 decoder 样本
            if len(decoder_idxs) > 0:
                yield {'type': 'decoder', 'batch': batch, 'decoder_idxs': decoder_idxs}
            # 如果当前批次有 encoder 样本
            if len(encoder_idxs) > 0:
                yield {'type': 'encoder', 'batch': batch, 'encoder_idxs': encoder_idxs}





class Data_mr:
    def __init__(self, X_train, X_val, X_test):
        self.X_train = X_train
        self.X_val = X_val
        self.X_test = X_test

        self.n_pool = len(X_train)
        self.n_val = len(X_val)
        self.n_test = len(X_test)

        self.labeled_idxs = np.zeros(self.n_pool, dtype=int)
        self.sample_weights = np.ones(self.n_pool, dtype=float)
        self.selection_round = np.zeros(self.n_pool, dtype=int)
        self.max_rounds = 1


    def update_weights(self, current_round):
        self.max_rounds = max(self.max_rounds, current_round)
        selected_mask = self.selection_round > 0
        rounds_trained = current_round - self.selection_round[selected_mask] + 1

        base_weights = 1.0 / np.sqrt(rounds_trained)
        round_importance = self.selection_round[selected_mask] / self.max_rounds
        # 组合权重计算
        self.sample_weights[selected_mask] = base_weights * (0.5 + 0.5 * round_importance)

        # 规范化权重到【0.1, 1.0】范围
        if len(self.sample_weights[selected_mask]) > 0:
            weights_min = self.sample_weights[selected_mask].min()
            weights_max = self.sample_weights[selected_mask].max()
            if weights_max > weights_min:
                self.sample_weights[selected_mask] = 0.1 + 0.9 * (self.sample_weights[selected_mask] - weights_min) / (weights_max - weights_min)

        # 打印权重更新信息
        if np.sum(selected_mask) > 0:
            print(f"更新的样本数量： {np.sum(selected_mask)}")
            print(f"权重范围: [{self.sample_weights[selected_mask].min():.4f}, {self.sample_weights[selected_mask].max():.4f}]")
            print(f"平均权重：{self.sample_weights[selected_mask].mean():.4f}")


    def get_labeled_data(self):
        """获取已标记的训练数据"""
        # 获取标记为 2 或 3 的样本索引（分别代表 top 和 bottom 样本）
        labeled_idxs = np.arange(self.n_pool)[np.logical_or(self.labeled_idxs == 2, self.labeled_idxs == 3)]
        labeled_data = self.X_train[labeled_idxs]
        labeled_weights = self.sample_weights[labeled_idxs]
        # 返回数据对列表，包含数据和对应的标签
        return [(labeled_data[i], labeled_weights[i]) for i in range(len(labeled_data))]


    def get_unlabeled_data(self):
        unlabeled_idxs = np.arange(self.n_pool)[self.labeled_idxs == 0]
        unlabeled_data = self.X_train[unlabeled_idxs]

        return [(unlabeled_data[i], unlabeled_idxs[i]) for i in range(len(unlabeled_data))]

    def get_train_data(self):
        return self.labeled_idxs.copy(), self.X_train,
    def get_val_data(self):
        # 直接返回数据对，无需创建额外的索引
        return [self.X_val[i] for i in range(len(self.X_val))]

    def get_test_data(self):
        return [self.X_test[i] for i in range(len(self.X_test))]


class InitialDataset_mr(Dataset):
    def __init__(self, data_object):
        self.X = data_object.X_train
        self.labeled_idxs = data_object.labeled_idxs
        # 筛选出labeled_idxs为1的数据
        valid_idxs = np.where(self.labeled_idxs == 1)[0]
        self.X = self.X[valid_idxs]

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return {'batch': {'data': self.X[idx]}}


class SelectDataset_mr(Dataset):
    def __init__(self, data_object, current_round):
        # 从 Data 类对象中提取数据
        self.X = data_object.X_train
        self.labeled_idxs = data_object.labeled_idxs
        # 获取样本权重
        self.weights = data_object.sample_weights

        # 筛选出 labled_idxs 为 2 或 3 的数据
        valid_idxs = np.where((self.labeled_idxs == 2) | (self.labeled_idxs == 3))[0]
        self.X = self.X[valid_idxs]
        self.labeled_idxs = self.labeled_idxs[valid_idxs]
        # 获取对应的权重
        self.weights = self.weights[valid_idxs]
        # 归一化权重，以确保训练稳定
        self.weights = self.weights / np.sum(self.weights)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return {'data': self.X[idx], 'labeled': self.labeled_idxs[idx], 'weight': self.weights[idx]}


# 自定义DataLoader类
class SelectBatchDataLoader_mr(DataLoader):
    def __init__(self, dataset, batch_size=4, shuffle=False, **kwargs):
        super().__init__(dataset, batch_size=batch_size, shuffle=shuffle, **kwargs)

    def __iter__(self):
        # 按顺序迭代所有批次
        batch_generator = super().__iter__()
        while True:
            batch = next(batch_generator)
            labeled = batch['labeled'].numpy()

            # 获取属于 decoder (2) 的样本和 encoder (3) 的样本
            decoder_idxs = np.where(labeled == 2)[0]
            encoder_idxs = np.where(labeled == 3)[0]

            # 如果当前批次有 decoder 样本
            if len(decoder_idxs) > 0:
                yield {'type': 'decoder', 'batch': batch, 'decoder_idxs': decoder_idxs}

            # 如果当前批次有 encoder 样本
            if len(encoder_idxs) > 0:
                yield {'type': 'encoder', 'batch': batch, 'encoder_idxs': encoder_idxs}



def extract_data_mr(loader):
    X = []
    for images, _ in loader:
        # 以 Tensor 形式保存
        X.extend(images)
    return torch.cat(X, dim=0).unsqueeze(1)

def extract_data(loader):
    X, Y = [], []
    for images, labels, _ in loader:
        # 以 Tensor 形式保存
        X.extend(images)
        Y.extend(labels)
    return torch.cat(X, dim=0).unsqueeze(1), torch.cat(Y, dim=0).unsqueeze(1)


