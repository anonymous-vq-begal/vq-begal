import torch
import argparse
import os
import gc
import json
import math
import numpy as np

import torch
from torch import nn, optim
from torch.cuda.amp import autocast, GradScaler
from torch.utils.data import DataLoader, Subset
from torchvision.transforms import transforms
from sklearn.model_selection import KFold, train_test_split

from dataset import CTImageDataset, MRImageDataset, RepeatDataset
from query_strategy.al_ori1 import Net, Bio_EntropySampling, RandomSampling
from query_strategy.strategy import Strategy
from query_strategy.data import (Data, Data_mr, extract_data, extract_data_mr)
from unet_vq_5 import Unet_vq_optimized

from prefetch_generator import BackgroundGenerator


# 是否使用cuda
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 数据预处理
data_transforms = {
    'Train_Sets': transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.RandomVerticalFlip(p=0.5),   # 添加垂直翻转
        transforms.RandomRotation(20),    # 添加随机旋转
        transforms.ColorJitter(brightness=0.15, contrast=0.15),  # 添加颜色抖动
        transforms.ToTensor(),
        transforms.Normalize([0.5], [0.5])
    ]),
    'Test_Sets': transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize([0.5], [0.5])
    ]),
}


def dice_coefficient(pred, target, epsilon=1e-6):
    pred = torch.sigmoid(pred)
    pred = pred.view(-1)
    target = target.view(-1)

    intersection = (pred * target).sum()

    return (2. * intersection + epsilon) / (pred.sum() + target.sum() + epsilon)

# 优化数据加载
class DataLoaderX(DataLoader):
    def __iter__(self):
        return BackgroundGenerator(super().__iter__())

# 添加预加载和缓存机制
class CachedDataset:
    def __init__(self, dataset, cache_size=100):
        self.dataset = dataset
        self.cache_size = cache_size
        self.cache = {}

    def __getitem__(self, idx):
        if idx not in self.cache:
            if len(self.cache) >= self.cache_size:
                # 移除最早的缓存
                self.cache.pop(next(iter(self.cache)))
            self.cache[idx] = self.dataset[idx]
        return self.cache[idx]

    def __len__(self):
        return len(self.dataset)

def create_data_loaders(ct_dataset, mr_dataset, batch_size, num_workers=4):
    print(f"Original CT dataset size: {len(ct_dataset)}")
    print(f"Original MR dataset size: {len(mr_dataset)}")

    dataset_size = len(ct_dataset)
    indices = list(range(dataset_size))

    # 计算需要的重复次数，确保大于CT数据集大小
    mr_full_size = len(mr_dataset)
    repeat_times = math.ceil(dataset_size / mr_full_size)

    # 创建重复的MR数据集
    repeated_mr = RepeatDataset(mr_dataset, repeat_times)
    print(f"Repeated MR dataset size: {len(repeated_mr)}")

    # 划分数据集
    train_val_indices, test_indices = train_test_split(indices, test_size=0.15, random_state=42)
    train_indices, val_indices = train_test_split(train_val_indices, test_size=0.176, random_state=42)

    # 创建子集
    ct_train = Subset(ct_dataset, train_indices)
    ct_val = Subset(ct_dataset, val_indices)
    ct_test = Subset(ct_dataset, test_indices)

    # 为MR数据集创建对应长度的索引
    mr_train = Subset(repeated_mr, range(len(train_indices)))
    mr_val = Subset(repeated_mr, range(len(val_indices)))
    mr_test = Subset(repeated_mr, range(len(test_indices)))

    # 验证子集大小
    print("\nSubset sizes:")
    print(f"CT train: {len(ct_train)}, MR train: {len(mr_train)}")
    print(f"CT val: {len(ct_val)}, MR val: {len(mr_val)}")
    print(f"CT test: {len(ct_test)}, MR test: {len(mr_test)}")

    loader_kwargs = {
        'batch_size': batch_size,
        'num_workers': num_workers,
        'pin_memory': True,
        'prefetch_factor': 2,
        'persistent_workers': True
    }

    train_loader = DataLoaderX(
        CachedDataset(ct_train),
        shuffle=True,
        drop_last=True,
        **loader_kwargs
    )
    mr_train_loader = DataLoaderX(
        CachedDataset(mr_train),
        shuffle=True,
        drop_last=True,
        **loader_kwargs
    )
    val_loader = DataLoaderX(
        CachedDataset(ct_val),
        shuffle=False,
        **loader_kwargs
    )
    mr_val_loader = DataLoaderX(
        CachedDataset(mr_val),
        shuffle=False,
        **loader_kwargs
    )
    test_loader = DataLoaderX(
        CachedDataset(ct_test),
        shuffle=False,
        **loader_kwargs
    )
    mr_test_loader = DataLoaderX(
        CachedDataset(mr_test),
        shuffle=False,
        **loader_kwargs
    )

    return {
        'train': (train_loader, mr_train_loader),
        'val': (val_loader, mr_val_loader),
        'test': (test_loader, mr_test_loader),
        'indices': {
            'train': train_indices,
            'val': val_indices,
            'test': test_indices
        }
    }


def create_kfold_loaders(ct_dataset, mr_dataset, train_indices, batch_size, num_workers=4, n_splits=5):
    """
    Creates K-fold cross validation data loaders

    Args:
        ct_dataset: CT dataset
        mr_dataset: MR dataset
        train_indices: Indices for training data
        batch_size: Batch size for data loading
        num_workers: Number of worker processes
        n_splits: Number of folds

    Returns:
        list: List of dictionaries containing fold data loaders
    """
    kfold = KFold(n_splits=n_splits, shuffle=True, random_state=42)
    fold_loaders = []

    loader_kwargs = {
        'batch_size': batch_size,
        'num_workers': num_workers,
        'pin_memory': True,
        'prefetch_factor': 2,
        'persistent_workers': True
    }

    for fold, (train_fold_indices, val_fold_indices) in enumerate(kfold.split(train_indices)):
        # Get current fold indices
        current_train_indices = [train_indices[i] for i in train_fold_indices]
        current_val_indices = [train_indices[i] for i in val_fold_indices]

        # Create CT subsets
        ct_train = Subset(ct_dataset, current_train_indices)
        ct_val = Subset(ct_dataset, current_val_indices)

        # Create MR subsets matching the CT data size
        mr_train = Subset(mr_dataset, range(len(current_train_indices)))
        mr_val = Subset(mr_dataset, range(len(current_val_indices)))

        # Create loaders for this fold
        fold_loaders.append({
            'train': (
                DataLoaderX(CachedDataset(ct_train), shuffle=True, drop_last=True, **loader_kwargs),
                DataLoaderX(CachedDataset(mr_train), shuffle=True, drop_last=True, **loader_kwargs)
            ),
            'val': (
                DataLoaderX(CachedDataset(ct_val), shuffle=False, **loader_kwargs),
                DataLoaderX(CachedDataset(mr_val), shuffle=False, **loader_kwargs)
            )
        })

    return fold_loaders


class BinaryClassifier(nn.Module):
    def __init__(self, num_input_channels=512, num_class=2):
        super(BinaryClassifier, self).__init__()

        # 特征空间转换
        self.feature_transform = nn.Sequential(
            nn.Conv2d(num_input_channels, 256, 1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.Dropout2d(0.5),
            nn.Conv2d(256, 128, 1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.Dropout2d(0.5),

        )

        # 空间注意力
        self.spatial_attention = nn.Sequential(
            nn.Conv2d(128, 1, 7, padding=3),
            nn.Sigmoid()
        )

        # 通道注意力
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.channel_attention = nn.Sequential(
            nn.Linear(128, 32),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),  # 添加dropout
            nn.Linear(32, 128),
            nn.Sigmoid()
        )

        # 全局特征提取
        self.global_pool = nn.AdaptiveAvgPool2d(1)

        # 分类头
        self.classifier = nn.Sequential(
            nn.Linear(128, 64),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(64, num_class)
        )

        self.l2_lambda = 0.01
        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)

    def get_l2_regularization(self):
        l2_reg = torch.tensor(0., requires_grad=True)
        for param in self.parameters():
            l2_reg = l2_reg + torch.norm(param, 2)
        return self.l2_lambda * l2_reg

    def forward(self, x):
        # 特征变换
        feat_trans = self.feature_transform(x)
        # 空间注意力
        spatial_weight = self.spatial_attention(feat_trans)
        x = feat_trans * spatial_weight

        # 通道注意力
        b, c, _, _ = x.size()
        channel_weight = self.avg_pool(x).view(b, c)
        channel_weight = self.channel_attention(channel_weight).view(b, c, 1, 1)
        x = x * channel_weight

        # 全局特征
        x = self.global_pool(x)
        x = x.view(x.size(0), -1)
        # 分类
        x = self.classifier(x)

        return x

def create_binary_model(in_channels=512, n_class=2):
    return BinaryClassifier(num_input_channels=in_channels, num_class=n_class)


def create_optimizer_and_scheduler(model, binary_model, train_loader):
    # Stage 1 - 增加学习率
    base_lr = 5e-5
    stage1_param_groups = [
        {'params': model.encoder.parameters(), 'lr': base_lr * 0.5, 'name': 'encoder'},
        {'params': model.vqvae.parameters(), 'lr': base_lr * 0.5, 'name': 'vqvae'},
        {'params': model.adaptor.parameters(), 'lr': base_lr * 0.5, 'name': 'adaptor'},
        {'params': binary_model.parameters(), 'lr': base_lr, 'name': 'classifier'}
    ]


    # 创建两个优化器
    stage1_optimizer = optim.AdamW(
        stage1_param_groups,
        weight_decay=0.01,
        betas=(0.9, 0.999),
        eps=1e-8,
        amsgrad=True
    )

    steps_per_epoch = len(train_loader)
    num_training_steps = 100 * steps_per_epoch
    stage1_steps = num_training_steps


    def calculate_warmup_steps(total_steps):
        # 计算预热步数，保持较长的预热期但设置合理上限
        # base_warmup = total_steps // 10
        base_warmup = total_steps // 5

        return min(base_warmup, 2000)

    stage1_warmup_steps = calculate_warmup_steps(stage1_steps)

    # 学习率调度
    def stage1_lr_lamba(current_step):
        if current_step == 0:
            return 1.0    # 初始步返回1，保持原始学习率
        if current_step < stage1_warmup_steps:
            # 线性预热
            return float(current_step) / float(max(1, stage1_warmup_steps))
        # 预热后的余弦退火
        progress = float(current_step - stage1_warmup_steps) / float(max(1, stage1_steps - stage1_warmup_steps))
        return max(0.2, 0.5 * (1.0 + math.cos(math.pi * progress)))  # 调整余弦退火的下限


    stage1_scheduler = torch.optim.lr_scheduler.LambdaLR(stage1_optimizer, stage1_lr_lamba)

    # 添加梯度裁剪
    for group in stage1_param_groups:
        group['initial_lr'] = group['lr']
        group['max_grad_norm'] = 1.0  # 设置梯度裁剪阈值

    return stage1_optimizer, stage1_scheduler


class EarlyStopping:
    def __init__(self, patience=15, min_delta=1e-3, verbose=True):
        self.patience = patience
        self.min_delta = min_delta
        self.verbose = verbose
        self.counter = 0
        self.best_loss = None
        self.early_stop = False
        self.val_loss_min = float('inf')
        self.best_acc = 0

    def __call__(self, val_loss, val_acc):
        if self.best_loss is None:
            self.best_loss = val_loss
            self.best_acc = val_acc
        elif val_loss > self.best_loss - self.min_delta or \
             (val_loss <= self.best_loss and val_acc < self.best_acc * 0.9):  # 添加准确率检查
            self.counter += 1
            if self.verbose:
                print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_loss = val_loss
            self.best_acc = max(val_acc, self.best_acc)  # 更新最佳准确率
            self.counter = 0
        return self.early_stop

def log_lr_stats(optimizer):
    # 用于监控每个参数组的学习率
    for i, group in enumerate(optimizer.param_groups):
        print(f"Parameter group {group['name']}: lr = {group['lr']:.6f}")

def check_features(model, binary_model, dataload, mr_dataload, device):
    """检查编码器输出的特征分布"""
    model.eval()
    feature_stats = {
        'ct': {'means': [], 'stds': [], 'mins': [], 'maxs': []},
        'mr': {'means': [], 'stds': [], 'mins': [], 'maxs': []}
    }

    with torch.no_grad():
        for batch_idx, ((ct_x, _, _), (mr_x, _)) in enumerate(zip(dataload, mr_dataload)):
            if batch_idx > 5:  # 检查前6个batch
                break

            ct_x = ct_x.to(device)
            mr_x = mr_x.to(device)

            # 获取特征
            _, ct_features, mr_features, _, _ = model(ct_x, mr_x)

            # 收集CT特征统计信息
            feature_stats['ct']['means'].append(ct_features.mean().item())
            feature_stats['ct']['stds'].append(ct_features.std().item())

            # 收集MR特征统计信息
            feature_stats['mr']['means'].append(mr_features.mean().item())
            feature_stats['mr']['stds'].append(mr_features.std().item())

            # 检查是否有NaN
            if torch.isnan(ct_features).any() or torch.isnan(mr_features).any():
                print(f"\nWarning: NaN detected in features at batch {batch_idx}")


    return feature_stats


class GradientMonitor:
    def __init__(self, model=None, binary_model=None, model_clip_value=0.5, binary_clip_value=0.3, log_interval=50):
        """
        初始化梯度监控器
        Args:
            model: 主模型（encoder, vqvae, adaptor等）
            binary_model: 二分类器模型
            model_clip_value: 主模型的梯度裁剪阈值
            binary_clip_value: 二分类器的梯度裁剪阈值
            log_interval: 日志打印间隔
        """
        self.model = model
        self.binary_model = binary_model
        self.model_clip_value = model_clip_value
        self.binary_clip_value = binary_clip_value
        self.log_interval = log_interval
        self.step = 0

    def clip_gradients(self, parameters, clip_value):
        """梯度裁剪"""
        for param in parameters:
            if param.grad is not None:
                torch.nn.utils.clip_grad_norm_([param], clip_value)

    def get_grad_stats(self, parameters):
        """获取梯度统计信息"""
        grads = []
        zero_grad_count = 0
        total_params = 0

        for p in parameters:
            if p.grad is not None:
                grad = p.grad.abs()
                grads.append(grad)
                zero_grad_count += (grad == 0).sum().item()
                total_params += grad.numel()

        if grads:
            grads = torch.cat([g.flatten() for g in grads])
            return {
                'mean': grads.mean().item(),
                'std': grads.std(). item(),
                'min': grads.min().item(),
                'max': grads.max().item(),
                'zero_ratio': zero_grad_count / total_params if total_params > 0 else 0
            }
        return None

    def log_component_gradients(self, name, stats, detailed=False):
        if stats and detailed:
            print(f"{name} - Mean: {stats['mean']:.4f}, Std: {stats['std']:.4f}, "
                  f"Max: {stats['max']:.4f}, Min: {stats['min']:.4f}, "
                  f"Zero gradient ratio: {stats['zero_ratio']:.2%}")

    def monitor_step(self, model=None, binary_model=None, detailed=False):
        """监控一个训练步骤的梯度"""
        self.step += 1
        if self.step % self.log_interval != 0:
            return None

        model_to_check = model or self.model
        binary_model_to_check = binary_model or self.binary_model

        if model_to_check is None:
            raise ValueError("No model provided")

        components = {
            'Encoder': model_to_check.encoder,
            'VQVAE': model_to_check.vqvae,
            'Adaptor': model_to_check.adaptor
        }

        stats = {}
        # 检查主模型各组件
        for name, component in components.items():
            # 裁剪梯度，使用主模型的裁剪值
            self.clip_gradients(component.parameters(), self.model_clip_value)
            # 获取并记录统计信息
            component_stats = self.get_grad_stats(component.parameters())
            if component_stats:
                stats[name] = component_stats
                self.log_component_gradients(name, component_stats, detailed)

        # 检查二分类器，使用二分类器的裁剪值
        if binary_model_to_check is not None:
            self.clip_gradients(binary_model_to_check.parameters(), self.binary_clip_value)
            binary_stats = self.get_grad_stats(binary_model_to_check.parameters())
            if binary_stats:
                stats['Binary Classifier'] = binary_stats
                self.log_component_gradients('Binary Classifier', binary_stats, detailed)

        return stats




def train_model(model, binary_model, dataload, mr_dataload, valid_dataloaders, mr_valid_dataloaders, fold_num, num_epochs):
    try:
        os.makedirs('./model', exist_ok=True)

        # 冻结decoder
        for param in model.decoder.parameters():
            param.requires_grad = False

        # 确保其他组件可训练
        for param in model.encoder.parameters():
            param.requires_grad = True
        for param in model.vqvae.parameters():
            param.requires_grad = True
        for param in model.adaptor.parameters():
            param.requires_grad = True

        # 创建优化器和调度器
        stage1_optimizer, stage1_scheduler = create_optimizer_and_scheduler(model, binary_model, dataload)


        # 创建梯度监控器
        gradient_monitor = GradientMonitor(
            model,
            binary_model,
            model_clip_value=0.5,
            binary_clip_value=0.3,
            log_interval=50
        )


        # 早停和性能追踪
        early_stopping = EarlyStopping(patience=15, min_delta=1e-3, verbose=True)
        best_validation_loss = float('inf')
        beat_model_state = None

        # 混合精度训练配置
        scaler = GradScaler(
            init_scale=2**8,
            growth_factor=1.1,
            backoff_factor=0.8,
            growth_interval=2000,
            enabled=True
        )

        criterion = nn.CrossEntropyLoss(label_smoothing=0.1)

        stage = 1
        for epoch in range(1, num_epochs+1):
            print(f'Stage {stage}, Fold {fold_num}, Epoch {epoch}/{num_epochs}')
            print('-' * 10)

            # 只在epoch开始和每10个epoch打印学习率
            if epoch == 1 or epoch % 10 ==0:
                log_lr_stats(stage1_optimizer)

            model.train()
            binary_model.train()


            epoch_metrics = {
                'loss': 0, 'class_loss': 0,
                'correct_pred': 0, 'total_pred': 0
            }

            steps = 0

            for batch_idx, ((x, _, class_y), (mr_x, mr_class_y)) in enumerate(zip(dataload, mr_dataload)):
                steps += 1

                inputs = x.to(device, non_blocking=True)
                mr_inputs = mr_x.to(device, non_blocking=True)
                mr_class_y = mr_class_y.to(device, non_blocking=True)
                class_y = class_y.to(device, non_blocking=True)

                # 使用混合精度训练
                with autocast():
                    if stage == 1:
                        _, ct_encode_feature, mr_encode_feature, _, _ = model(inputs, mr_inputs)

                        # 计算分类损失: 修改为log_softmax + nll_Loss的组合
                        ct_logits = binary_model(ct_encode_feature)
                        ct_loss = criterion(ct_logits, class_y.long().squeeze())

                        mr_logits = binary_model(mr_encode_feature)
                        mr_loss = criterion(mr_logits, mr_class_y.long().squeeze())

                        # 添加L2正则化损失
                        l2_reg_loss = binary_model.get_l2_regularization()

                        # 检查分类器输出
                        if torch.isnan(ct_logits).any() or torch.isnan(mr_logits).any():
                            print(f"NaN in classifier output at batch {batch_idx}")
                            continue

                        # 计算总分类损失
                        total_class_loss = ct_loss + mr_loss
                        total_loss = total_class_loss

                stage1_optimizer.zero_grad()
                scaler.scale(total_loss).backward()

                # 每100个batch打印详细信息，其他时候打印简略信息
                grad_stats = gradient_monitor.monitor_step(detailed=(batch_idx % 100 == 0))

                scaler.unscale_(stage1_optimizer)


                # 检查优化器步骤
                scaler.step(stage1_optimizer)
                scaler.update()
                stage1_scheduler.step()

                # 计算分类准确率
                with torch.no_grad():
                    for logits, targets in [(ct_logits, class_y), (mr_logits, mr_class_y)]:
                        _, predicted = torch.max(logits, 1)
                        epoch_metrics['correct_pred'] += (predicted == targets.squeeze()).sum().item()
                        epoch_metrics['total_pred'] += targets.size(0)


                # 累积度量
                epoch_metrics['loss'] += total_loss.item()
                epoch_metrics['class_loss'] += total_class_loss.item()

                # 每100个batch检查一次特征
                if batch_idx % 100 == 0:
                    # print(f"\nBatch {batch_idx} Feature Check:")
                    check_features(model, binary_model, [(inputs, _, class_y)], [(mr_inputs, mr_class_y)], device)

                # 定期清理缓存
                if batch_idx % 5 == 0:
                    torch.cuda.empty_cache()

            # 计算epoch平均指标
            epoch_accuracy = epoch_metrics['correct_pred'] / epoch_metrics['total_pred']
            avg_class_loss = epoch_metrics['class_loss'] / steps
            print(f"Epoch {epoch} - Class Loss: {avg_class_loss:.4f}, Accuracy: {epoch_accuracy:.2%}")

            # Validate the model at the end of the epoch
            model.eval()
            binary_model.eval()

            val_metrics = validate_model(model, binary_model, valid_dataloaders, mr_valid_dataloaders, epoch, num_epochs)

            print(f"Validation - Loss: {val_metrics['loss']:.4f}, Val_Accuracy: {val_metrics['accuracy']:.2f}%")

            # 检查是否保存最佳模型
            if val_metrics['loss'] < best_validation_loss:
                best_validation_loss = val_metrics['loss']
                best_model_state = {
                    'epoch': epoch,
                    'model_state_dict': model.state_dict(),
                    'binary_model_state_dict': binary_model.state_dict(),
                    'optimizer_state_dict': stage1_optimizer.state_dict(),
                    'scheduler_state_dict': stage1_scheduler.state_dict(),
                    'loss': best_validation_loss,
                    'metrics': val_metrics
                }
                torch.save(best_model_state, f'./model/best_stage1_model_fold_{fold_num}.pth')
                print(f"Saved new best model with validation loss: {best_validation_loss:.4f}")

            # Early stopping检查
            if early_stopping(val_metrics['loss'], val_metrics['accuracy']):
                print(f"Early stopping triggered at epoch {epoch}")
                break

            gc.collect()
            torch.cuda.empty_cache()

    except Exception as e:
        print(f"Training error: {str(e)}")
        raise e

    return best_model_state, best_validation_loss


def validate_model(model, binary_model, valid_loader, mr_valid_loader, current_epoch, total_epochs):
    model.eval()
    binary_model.eval()

    val_metrics = {
        'loss': 0, 'class_loss': 0,
        'correct_pred': 0, 'total_pred': 0
    }
    steps = 0
    criterion = nn.CrossEntropyLoss(label_smoothing=0.1)

    with torch.no_grad():
        for (x, y, class_y), (mr_x, mr_class_y) in zip(valid_loader, mr_valid_loader):
            steps += 1

            inputs = x.to(device, non_blocking=True)
            mr_inputs = mr_x.to(device, non_blocking=True)
            class_y = class_y.to(device, non_blocking=True)
            mr_class_y = mr_class_y.to(device, non_blocking=True)

            with autocast():
                _, ct_encode_feature, mr_encode_feature, _, _ = model(inputs, mr_inputs)

                # 分类预测
                ct_logits = binary_model(ct_encode_feature)
                mr_logits = binary_model(mr_encode_feature)

                # 计算损失
                ct_loss = criterion(ct_logits, class_y.long().squeeze())
                mr_loss = criterion(mr_logits, mr_class_y.long().squeeze())
                class_loss = ct_loss + mr_loss
                total_loss = class_loss

            val_metrics['loss'] += class_loss.item()
            # 计算准确率
            for logits, targets in [(ct_logits, class_y), (mr_logits, mr_class_y)]:
                _, predicted = torch.max(logits, 1)
                val_metrics['correct_pred'] += (predicted == targets.squeeze()).sum().item()
                val_metrics['total_pred'] += targets.size(0)

    # 计算平均指标
    for key in ['loss', 'class_loss']:
        val_metrics[key] /= steps

    val_metrics['accuracy'] = val_metrics['correct_pred'] / val_metrics['total_pred'] * 100

    return val_metrics



def train_classifier(args):
    """第一阶段：使用K折交叉验证训练和选择最佳分类器"""
    print("Starting classifier training phase...")


    # 创建数据集
    data_dir = './chaos_data/CHAOS_Train_Sets'
    ct_dataset = CTImageDataset(data_dir, transform=data_transforms['Train_Sets'])
    mr_dataset = MRImageDataset(data_dir, transform=data_transforms['Train_Sets'])

    # 创建所有数据加载器
    data_loaders = create_data_loaders(
        ct_dataset,
        mr_dataset,
        batch_size=args.batch_size,
        num_workers=args.num_workers
    )

    # 打印数据集信息
    print("\nDataset splits:")
    total_size = len(ct_dataset)
    train_size = len(data_loaders['indices']['train'])
    val_size = len(data_loaders['indices']['val'])
    test_size = len(data_loaders['indices']['test'])

    print(f"Total dataset size: {total_size}")
    print(f"Training set size: {train_size} ({train_size / total_size * 100:.1f}%)")
    print(f"Validation set size: {val_size} ({val_size / total_size * 100:.1f}%)")
    print(f"Test set size: {test_size} ({test_size / total_size * 100:.1f}%)")


    # 创建K-fold数据加载器
    fold_loaders = create_kfold_loaders(
        ct_dataset,
        mr_dataset,
        data_loaders['indices']['train'],
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        n_splits=args.n_folds
    )

    # 开始K-fold训练
    fold_results = []
    best_checkpoint = None
    best_fold_loss = float('inf')
    best_fold = -1

    for fold, fold_loader in enumerate(fold_loaders):
        print(f'\nTraining Fold {fold + 1}/{args.n_folds}')

        # 初始化模型
        model = Unet_vq_optimized(1, 1).to(device)
        binary_model = create_binary_model().to(device)


        # 训练Stage 1
        fold_model_state, fold_val_loss = train_model(
            model,
            binary_model,
            fold_loader['train'][0],  # CT train loader
            fold_loader['train'][1],  # MR train loader
            fold_loader['val'][0],  # CT val loader
            fold_loader['val'][1],  # MR val loader
            fold_num=fold + 1,
            num_epochs=100
        )


        # 更新最佳模型
        if fold_val_loss < best_fold_loss:
            best_fold_loss = fold_val_loss
            best_fold = fold + 1
            # 保存最佳模型检查点
            best_checkpoint = {
                'model_state_dict': model.state_dict(),
                'binary_model_state_dict': binary_model.state_dict(),
                'fold': fold + 1,
                'val_loss': fold_val_loss,
                'args': args.__dict__
            }
            torch.save(best_checkpoint, f'best_model_fold_{best_fold}.pth')

        fold_results.append({
            'fold': fold + 1,
            'val_loss': fold_val_loss
        })

        # 清理内存
        del model, binary_model
        gc.collect()
        torch.cuda.empty_cache()

    # 打印交叉验证结果
    print("\nCross-validation results:")
    avg_val_loss = sum(r['val_loss'] for r in fold_results) / len(fold_results)
    for result in fold_results:
        print(f"Fold {result['fold']}: Validation Loss = {result['val_loss']:.4f}")
    print(f"\nAverage validation loss: {avg_val_loss:.4f}")
    print(f"Best fold: {best_fold} with validation loss: {best_fold_loss:.4f}")

    # 保存完整的评估结果
    results_summary = {
        'cross_validation': {
            'avg_val_loss': avg_val_loss,
            'best_fold': best_fold,
            'best_fold_loss': best_fold_loss,
            'fold_results': fold_results
        },
        'training_config': {
            'batch_size': args.batch_size,
            'num_epochs': 100,
            'learning_rate': 5e-5,
            'n_folds': args.n_folds,
            'weight_decay': 0.01
        }
    }

    # 保存评估结果
    with open('final_evaluation_results.json', 'w') as f:
        json.dump(results_summary, f, indent=4)

    print("\n完整评估结果已保存至 'final_evaluation_results.json'")


# 训练模型
def train_active_learning(args):
    """第二阶段：使用主动学习进行训练"""
    print("Starting active learning phase...")

    args.batch_size = 16
    args.learning_rate = 1e-4
    args.min_lr = 1e-6
    args.warmup_epochs = 5

    # 创建数据集和数据加载器
    data_dir = './chaos_data/CHAOS_Train_Sets'
    ct_dataset = CTImageDataset(data_dir, transform=data_transforms['Train_Sets'])
    mr_dataset = MRImageDataset(data_dir, transform=data_transforms['Train_Sets'])

    # 获取最佳分类器模型的fold
    best_fold = None
    best_loss = float('inf')
    for fold in range(1, args.n_folds + 1):
        model_path = f'best_model_fold_{fold}.pth'
        if os.path.exists(model_path):
            checkpoint = torch.load(model_path)
            if checkpoint['val_loss'] < best_loss:
                best_loss = checkpoint['val_loss']
                best_fold = fold

    if best_fold is None:
        raise ValueError("No trained classifier models found!")

    print(f"Loading best classifier model from fold {best_fold}")

    # 加载最佳模型
    best_model_path = f'best_model_fold_{best_fold}.pth'
    checkpoint = torch.load(best_model_path)

    # 初始化模型并加载权重
    model = Unet_vq_optimized(1, 1).to(device)
    binary_model = create_binary_model().to(device)
    model.load_state_dict(checkpoint['model_state_dict'])
    binary_model.load_state_dict(checkpoint['binary_model_state_dict'])

    # 冻结binary_model的参数
    for param in binary_model.parameters():
        param.requires_grad = False

    # 创建数据加载器
    data_loaders = create_data_loaders(
        ct_dataset,
        mr_dataset,
        batch_size=args.batch_size,
        num_workers=args.num_workers
    )

    # 提取训练和验证数据
    ct_X_train, ct_Y_train = extract_data(data_loaders['train'][0])
    ct_X_val, ct_Y_val = extract_data(data_loaders['val'][0])
    ct_X_test, ct_Y_test = extract_data(data_loaders['test'][0])  # 添加测试集

    mr_X_train = extract_data_mr(data_loaders['train'][1])
    mr_X_val = extract_data_mr(data_loaders['val'][1])
    mr_X_test = extract_data_mr(data_loaders['test'][1])

    # 初始化数据对象
    ct_data = Data(ct_X_train, ct_Y_train, ct_X_val, ct_Y_val, ct_X_test, ct_Y_test)
    mr_data = Data_mr(mr_X_train, mr_X_val, mr_X_test)

    # 初始化网络和策略
    net = Net(model, binary_model, device, args)
    strategy = Bio_EntropySampling(ct_data, mr_data, net, args)
    # strategy = RandomSampling(ct_data, mr_data, net, args)

    # 初始化标记池

    print("=== Initial Data Statistics ===")
    print(f"Unlabeled pool size: {ct_data.n_pool}")
    print(f"Validation pool size: {ct_data.n_val}")
    print(f"Test pool size: {ct_data.n_test}")

    # 创建目录保存模型权重和结果
    os.makedirs('./model/active_learning', exist_ok=True)
    os.makedirs('./results/active_learning', exist_ok=True)

    # 主动学习循环
    results = {
        'rounds': [],
        'validation_metrics': [],
        'test_metrics': [],
        'labeled_size': [],
        'training_histories': [],
        'learning_rates': [],
        'best_scores': {'dice': 0.0, 'round': 0}
    }

    # 初始化最佳验证指标和性能监控
    best_validation_dice = 0.0
    best_round = 0
    consecutive_decline = 0  # 连续性能下降计数
    previous_val_dice = 0.0  # 上一轮的验证集Dice分数
    reset_threshold = args.reset_threshold if hasattr(args, 'reset_threshold') else 3  # 连续下降超过阈值时重置

    for rd in range(1, args.n_round + 1):
        print(f"\nActive Learning Round {rd}/{args.n_round}")

        try:
            # 加载模型权重策略
            if rd > 1:
                # 常规情况：加载上一轮的权重
                prev_model_path = f'./model/active_learning/weights_round_{rd - 1}.pth'

                # 如果连续性能下降超过阈值，加载最佳轮次的权重
                if consecutive_decline >= reset_threshold:
                    prev_model_path = f'./model/active_learning/weights_best_round_{best_round}.pth'
                    print(
                        f"Performance declined for {consecutive_decline} rounds. Loading best model from round {best_round}")
                    consecutive_decline = 0  # 重置计数器

                if os.path.exists(prev_model_path):
                    checkpoint = torch.load(prev_model_path)
                    net.model.load_state_dict(checkpoint['model_state_dict'])
                    if 'optimizer_de_state_dict' in checkpoint:
                        net.optimizers[0].load_state_dict(checkpoint['optimizer_de_state_dict'])
                        net.optimizers[1].load_state_dict(checkpoint['optimizer_en_state_dict'])
                    print(f"Loaded weights from {prev_model_path}")

            # 查询新样本
            top_idxs, bottom_idxs = strategy.query(args.n_query)

            # 更新标签池
            strategy.update(top_idxs, bottom_idxs, rd)

            # 训练模型
            training_history = strategy.bio_train(rd)

            # 评估当前轮次性能
            current_val_dice = training_history['valid_dice_scores'][-1]

            # 性能监控和保护机制
            if current_val_dice < previous_val_dice:
                consecutive_decline += 1
                print(f"Performance declined. Consecutive declines: {consecutive_decline}")
            else:
                consecutive_decline = 0

            previous_val_dice = current_val_dice

            # 更新最佳性能记录
            if current_val_dice > best_validation_dice:
                best_validation_dice = current_val_dice
                best_round = rd
                # 保存当前轮次的最佳权重
                torch.save({
                    'model_state_dict': net.model.state_dict(),
                    'optimizer_de_state_dict': net.optimizers[0].state_dict(),
                    'optimizer_en_state_dict': net.optimizers[1].state_dict(),
                    'scaler_state_dict': net.scaler.state_dict(),
                    'round': rd,
                    'validation_dice': current_val_dice
                }, f'./model/active_learning/weights_best_round_{rd}.pth')
                print(f"Saved new best model from round {rd} with validation dice: {current_val_dice:.4f}")

            # 始终保存当前轮次的权重（用于连续训练）
            torch.save({
                'model_state_dict': net.model.state_dict(),
                'optimizer_de_state_dict': net.optimizers[0].state_dict(),
                'optimizer_en_state_dict': net.optimizers[1].state_dict(),
                'scaler_state_dict': net.scaler.state_dict(),
                'round': rd,
                'validation_dice': current_val_dice
            }, f'./model/active_learning/weights_round_{rd}.pth')

            # 评估测试集性能
            print("Evaluating on test set...")
            test_data_list = ct_data.get_test_data()
            test_mr_data_list = mr_data.get_test_data()
            test_metrics = net.evaluate(test_data_list, test_mr_data_list)

            if test_metrics is not None:
                print(f"Round {rd} Results:")
                print(f"Validation Dice: {current_val_dice:.4f}")
                print(f"Test Loss: {test_metrics['loss']:.4f}")
                print(f"Test Dice: {test_metrics['dice']:.4f}")

            # 记录结果
            results['rounds'].append(rd)
            results['validation_metrics'].append({
                'loss': training_history['valid_losses'][-1],
                'dice': training_history['valid_dice_scores'][-1]
            })
            results['test_metrics'].append(test_metrics)
            results['labeled_size'].append(ct_data.get_labeled_size())

            # 保存当前轮次结果
            with open(f'./results/active_learning/results_round_{rd}.json', 'w') as f:
                json.dump({
                    'round': rd,
                    'validation_metrics': results['validation_metrics'][-1],
                    'test_metrics': test_metrics,
                    'labeled_size': results['labeled_size'][-1],
                    'training_history': training_history,
                    'consecutive_declines': consecutive_decline,
                    'best_round_so_far': best_round
                }, f, indent=4)

        except Exception as e:
            print(f"Error in round {rd}: {str(e)}")
            continue

        # 清理内存
        gc.collect()
        torch.cuda.empty_cache()

    save_final_results()
    print("\nActive learning training completed!")
    print(f"Best validation dice: {best_validation_dice:.4f} achieved in round {best_round}")

    def get_best_test_dice(test_metrics):
        """
        安全地获取最佳测试Dice值

        Args:
            test_metrics: 测试指标列表

        Returns:
            float or None: 最佳Dice值，如果没有有效值则返回None
        """
        # 过滤出非None且包含dice值的指标
        valid_metrics = [d['dice'] for d in test_metrics if d is not None and 'dice' in d]

        # 打印调试信息
        print(f"\nDebug - Test metrics analysis:")
        print(f"Total metrics entries: {len(test_metrics)}")
        print(f"Valid metrics entries: {len(valid_metrics)}")

        if not valid_metrics:
            print("Warning: No valid test dice scores found!")
            return None

        best_dice = max(valid_metrics)
        print(f"Best test dice score: {best_dice}")
        return best_dice


    # 保存最终结果
    final_results = {
        'n_rounds': args.n_round,
        'n_queries_per_round': args.n_query,
        'best_validation_dice': best_validation_dice,
        'best_round': best_round,
        'best_test_dice': get_best_test_dice(results['test_metrics']),
        'final_labeled_size': results['labeled_size'][-1],
        'training_config': vars(args),
        'complete_results': results
    }

    # 添加结果验证
    if final_results['best_test_dice'] is None:
        print("\nWarning: No valid test dice scores were found in the results.")
        print("This might indicate an issue with the test evaluation process.")
        # 保存原始测试指标以供调试
        final_results['debug_info'] = {
            'raw_test_metrics': results['test_metrics'],
            'test_metrics_count': len(results['test_metrics']),
            'non_none_metrics_count': len([x for x in results['test_metrics'] if x is not None])
        }

    # 保存结果
    with open('./results/active_learning/final_results.json', 'w') as f:
        json.dump(final_results, f, indent=4)

    print("Final results saved to './results/active_learning/final_results.json'")


def main():
    # 参数解析
    parse = argparse.ArgumentParser()
    # 基础训练参数
    parse.add_argument('--batch_size', type=int, default=32, help="batch size")
    parse.add_argument('--num_workers', type=int, default=4, help="number of workers for data loading")

    # 分类器训练阶段参数
    parse.add_argument('--n_folds', type=int, default=5, help="number of folds for cross validation")

    # 主动学习阶段参数
    parse.add_argument('--n_query', type=int, default=1000, help="number of queries per round")
    parse.add_argument('--n_round', type=int, default=1, help="number of rounds")
    parse.add_argument('--num_epochs', type=int, default=140)
    parse.add_argument('--learning_rate', type=float, default=3e-4)
    parse.add_argument('--weight_decay', type=float, default=0.01)
    parse.add_argument('--reset_threshold', type=int, default=3, help='Number of consecutive declines before reset')


    args = parse.parse_args()

    # 设置随机种子，确保结果可复现
    torch.manual_seed(42)
    torch.cuda.manual_seed(42)
    np.random.seed(42)
    torch.backends.cudnn.deterministic = True

    try:
        # 第一阶段：训练分类器
        # print("\n=== Starting Phase 1: Classifier Training ===")
        # train_classifier(args)
        # print("=== Classifier Training Completed ===\n")

        # 第二阶段：主动学习
        print("\n=== Starting Phase 2: Active Learning ===")
        train_active_learning(args)
        print("=== Active Learning Completed ===\n")

        print("Complete training pipeline finished successfully!")

    except Exception as e:
        print(f"Error occurred during training: {str(e)}")
        raise e


if __name__ == '__main__':
    main()

