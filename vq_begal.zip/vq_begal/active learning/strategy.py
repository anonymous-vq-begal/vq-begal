import numpy as np
import logging
import torch
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.cuda.amp import autocast, GradScaler
from query_strategy.data import (SelectDataset, SelectDataset_mr,
                                 SelectBatchDataLoader, SelectBatchDataLoader_mr
                                 )

class Strategy:
    def __init__(self, ct_data, mr_data, net, args):
        self.ct_data = ct_data
        self.mr_data = mr_data
        self.net = net
        self.args = args
        self.dataset = None
        self.mr_dataset = None
        self.dataloader = None
        self.mr_dataloader = None

        # 设置日志
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)

    def query(self, n):
        pass

    def update(self, top_idxs, bottom_idxs, current_round):
        """
        更新数据集和加载器
        Args:
            top_idxs: 顶部样本索引
            bottom_idxs: 底部样本索引
            current_round: 当前轮次
        """

        # 更新样本的选择批次
        self.ct_data.selection_round[top_idxs] = current_round
        self.ct_data.selection_round[bottom_idxs] = current_round

        # 更新标签状态
        self.ct_data.labeled_idxs[top_idxs] = 2
        self.mr_data.labeled_idxs[top_idxs] = 2
        self.ct_data.labeled_idxs[bottom_idxs] = 3
        self.mr_data.labeled_idxs[bottom_idxs] = 3

        # 更新权重
        self.ct_data.update_weights(current_round)


        self.dataset = SelectDataset(self.ct_data, current_round)
        self.mr_dataset = SelectDataset_mr(self.mr_data, current_round)

        # 打印数据集大小
        print(f"SelectDataset size: {len(self.dataset)}")
        print(f"SelectDataset_mr size: {len(self.mr_dataset)}")

        self.dataloader = SelectBatchDataLoader(self.dataset, batch_size=4, shuffle=False)
        self.mr_dataloader = SelectBatchDataLoader(self.mr_dataset, batch_size=4, shuffle=False)
        print(f"数据加载器长度: {len(self.dataloader)}")


    def bio_train(self, rd):
        """使用dataloader进行训练"""
        self.dataset = SelectDataset(self.ct_data, rd)
        self.mr_dataset = SelectDataset_mr(self.mr_data, rd)
        self.dataloader = SelectBatchDataLoader(self.dataset, batch_size=4, shuffle=True)
        self.mr_dataloader = SelectBatchDataLoader_mr(self.mr_dataset, batch_size=4, shuffle=True)

        # 获取验证数据
        valid_data_list = self.ct_data.get_val_data()
        valid_mr_data_list = self.mr_data.get_val_data()

        # 调用模型训练
        return self.net.bio_train(
            self.dataloader,  # 使用已经初始化的dataloader
            self.mr_dataloader,  # 使用已经初始化的mr_dataloader
            valid_data_list,
            valid_mr_data_list,
            rd
        )


    def predict_prob(self, data_list, mr_data_list):
        probs = self.net.predict_prob(data_list, mr_data_list)
        return probs




