import os
import torch
from torch.utils.data import DataLoader, Dataset, random_split
from torchvision.transforms.functional import to_tensor
from PIL import Image
import pydicom
import numpy as np
from skimage.transform import resize
from skimage import exposure




class CTImageDataset(Dataset):
    def __init__(self, root_dir, transform=None):
        super().__init__()
        self.root_dir = os.path.abspath(root_dir)
        self.transform = transform
        self.ct_image_paths = []
        self.ct_labels = []


        ct_dir = os.path.join(root_dir, 'CT')
        if os.path.isdir(ct_dir):
            for folder_name in os.listdir(ct_dir):
                folder_path = os.path.join(ct_dir, folder_name)
                dicom_dir = os.path.join(folder_path, 'DICOM_anon')
                self._add_dicom_images_from_directory_ct(dicom_dir)
                label_dir = os.path.join(folder_path, 'Ground')
                self._add_labels_from_directory_ct(label_dir)


    def _add_dicom_images_from_directory_ct(self, directory):
        """添加DICOM图像文件到数据集中"""
        if os.path.isdir(directory):
            for filename in sorted(os.listdir(directory)):
                if filename.endswith('.dcm'):
                    file_path = os.path.join(directory, filename)
                    self.ct_image_paths.append(file_path)

    def _add_labels_from_directory_ct(self, directory):
        """添加PNG标签文件到数据集中"""
        if os.path.isdir(directory):
            for filename in sorted(os.listdir(directory)):
                if filename.endswith('.png'):
                    file_path = os.path.join(directory, filename)
                    self.ct_labels.append(file_path)


    def _load_and_preprocess_dicom_image(self, file_path, target_size=(224, 224)):
        """加载和预处理DICOM图像"""
        dicom = pydicom.dcmread(file_path)
        image = dicom.pixel_array
        image = image.astype(np.float32)
        image = (image - np.min(image)) / (np.max(image) - np.min(image))
        image_resized = resize(image, target_size, mode='reflect', anti_aliasing=True)
        image_eq = exposure.equalize_hist(image_resized)
        # image_eq = np.stack((image_eq,) * 3, axis=-1)  # 将灰度图像转换为3通道RGB图像
        return Image.fromarray((image_eq * 255).astype(np.uint8))

    def _load_labels(self, file_path, target_size=(224, 224)):
        """加载PNG标签"""
        label_image = Image.open(file_path).convert('1')  # 转换为二值图像
        label_image_numpy = np.array(label_image, dtype=np.uint8)
        label_resized = resize(label_image_numpy, target_size, mode='reflect', anti_aliasing=False)
        label = to_tensor(label_resized)
        return label

    def __getstate__(self):
        state = self.__dict__.copy()
        return state

    def __setstate__(self, state):
        self.__dict__.update(state)


    def __len__(self):
        return len(self.ct_image_paths)

    def __getitem__(self, idx):
        img_path = self.ct_image_paths[idx]
        image = self._load_and_preprocess_dicom_image(img_path)
        label_path = self.ct_labels[idx]
        label = self._load_labels(label_path)
        if self.transform:
            image = self.transform(image)
        return image, label, torch.tensor([0.0], dtype=torch.float32)


class MRImageDataset(Dataset):
    def __init__(self, root_dir, transform=None):
        super().__init__()
        self.root_dir = os.path.abspath(root_dir)
        self.transform = transform
        self.mr_image_paths = []
        self.mr_labels = []

        # 加载数据路径
        mr_dir = os.path.join(root_dir, 'MR')
        if os.path.isdir(mr_dir):
            for folder_name in os.listdir(mr_dir):
                folder_path = os.path.join(mr_dir, folder_name)
                for sequence in ["T1DUAL", "T2SPIR"]:
                    dicom_dir = os.path.join(folder_path, sequence, 'DICOM_anon/InPhase')
                    self._add_dicom_images_from_directory_mr(dicom_dir)
                    dicom_dir = os.path.join(folder_path, sequence, 'DICOM_anon/OutPhase')
                    self._add_dicom_images_from_directory_mr(dicom_dir)
                    label_dir = os.path.join(folder_path, sequence, 'Ground')
                    self._add_labels_from_directory_mr(label_dir)

        # 存储数据集大小
        self.dataset_size = len(self.mr_image_paths)
        if self.dataset_size == 0:
            raise ValueError("No MR images found in the specified directory")
        print(f"Loaded {self.dataset_size} MR images")

    def _add_dicom_images_from_directory_mr(self, directory):
        if os.path.isdir(directory):
            for filename in sorted(os.listdir(directory)):
                if filename.endswith('.dcm'):
                    file_path = os.path.join(directory, filename)
                    self.mr_image_paths.append(file_path)

    def _add_labels_from_directory_mr(self, directory):
        if os.path.isdir(directory):
            for filename in sorted(os.listdir(directory)):
                if filename.endswith('.png'):
                    file_path = os.path.join(directory, filename)
                    self.mr_labels.append(file_path)

    def _load_and_preprocess_dicom_image(self, file_path, target_size=(224, 224)):
        try:
            dicom = pydicom.dcmread(file_path)
            image = dicom.pixel_array
            image = image.astype(np.float32)
            image = (image - np.min(image)) / (np.max(image) - np.min(image))
            image_resized = resize(image, target_size, mode='reflect', anti_aliasing=True)
            image_eq = exposure.equalize_hist(image_resized)
            return Image.fromarray((image_eq * 255).astype(np.uint8))
        except Exception as e:
            print(f"Error loading image {file_path}: {str(e)}")
            raise

    def _load_labels(self, file_path, target_size=(224, 224)):
        try:
            label_image = Image.open(file_path)
            label_image_numpy = np.array(label_image)
            label_resized = resize(label_image_numpy, target_size, mode='reflect', anti_aliasing=False)
            label = to_tensor(label_resized)
            return label
        except Exception as e:
            print(f"Error loading label {file_path}: {str(e)}")
            raise

    def __len__(self):
        return self.dataset_size

    def __getitem__(self, idx):
        # 使用取模运算确保索引在有效范围内
        idx = idx % self.dataset_size

        try:
            img_path = self.mr_image_paths[idx]
            image = self._load_and_preprocess_dicom_image(img_path)

            if self.transform:
                image = self.transform(image)

            return image, torch.tensor([1.0], dtype=torch.float32)
        except Exception as e:
            print(f"Error getting item at index {idx}: {str(e)}")
            print(f"Dataset size: {self.dataset_size}")
            print(f"Number of image paths: {len(self.mr_image_paths)}")
            raise

    def __getstate__(self):
        state = self.__dict__.copy()
        return state

    def __setstate__(self, state):
        self.__dict__.update(state)


class RepeatDataset(Dataset):
    def __init__(self, dataset, times):
        self.dataset = dataset
        self.times = times
        self.dataset_size = len(dataset)
        self.total_size = self.dataset_size * times

    def __getitem__(self, idx):
        if idx >= self.total_size:
            idx = idx % self.dataset_size
        return self.dataset[idx % self.dataset_size]

    def __len__(self):
        return self.total_size