import argparse
import copy
import gc
import json
import math
import os
from itertools import chain

import GPUtil
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
# 添加内存管理和性能监控
import psutil
import torch
import torch.nn.functional as F
import torch.nn.init as init
from prefetch_generator import BackgroundGenerator
from sklearn.model_selection import KFold, train_test_split
from torch import nn, optim
# 添加混合精度训练
from torch.cuda.amp import autocast, GradScaler
from torch.utils.data import DataLoader, Subset
from torchvision.transforms import transforms

from dataset import CTImageDataset, MRImageDataset, RepeatDataset
from unet_vq_5 import Unet_vq_optimized

# 是否使用cuda
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# 数据预处理
data_transforms = {
    'Train_Sets': transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.RandomVerticalFlip(p=0.5),   # 添加垂直翻转
        transforms.RandomRotation(20),    # 添加随机旋转
        transforms.ColorJitter(brightness=0.15, contrast=0.15),  # 添加颜色抖动
        transforms.ToTensor(),
        transforms.Normalize([0.5], [0.5])
    ]),
    'Test_Sets': transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize([0.5], [0.5])
    ]),
}

class CombinedLoss(nn.Module):
    def __init__(self, smooth=1):
        super().__init__()
        self.smooth = smooth
        self.bce = nn.BCEWithLogitsLoss()

    def forward(self, pred, target, epoch, total_epochs):
        progress = epoch / total_epochs
        # 使用更温和的权重变化
        if epoch < total_epochs // 3:
            # 早期阶段：BCE权重从0.8逐渐境地到0.6
            bce_weight = 0.8 - 0.2 * (epoch / (total_epochs // 3))
            dice_weight = 1 - bce_weight
        else:
            # 后期阶段： 更平缓的余弦退火
            current_alpha = 0.4 + 0.3 * (1 - math.cos(progress * math.pi)) / 2
            bce_weight = 1 - current_alpha
            dice_weight = current_alpha

        pred = torch.sigmoid(pred)
        intersection = (pred * target).sum()
        dice_loss = 1 - (2. * intersection + self.smooth) / (pred.sum() + target.sum() + self.smooth)
        bce_loss = self.bce(pred, target)

        # 添加权重平滑项
        weight_decay = 0.01 * (bce_weight ** 2 + dice_weight ** 2)

        return bce_weight * bce_loss + dice_weight * dice_loss + weight_decay



def dice_coefficient(pred, target, epsilon=1e-6):
    pred = torch.sigmoid(pred)
    pred = pred.view(-1)
    target = target.view(-1)
    intersection = (pred * target).sum()
    return (2. * intersection + epsilon) / (pred.sum() + target.sum() + epsilon)

# 优化数据加载
class DataLoaderX(DataLoader):
    def __iter__(self):
        return BackgroundGenerator(super().__iter__())

# 添加预加载和缓存机制
class CachedDataset:
    def __init__(self, dataset, cache_size=100):
        self.dataset = dataset
        self.cache_size = cache_size
        self.cache = {}

    def __getitem__(self, idx):
        if idx not in self.cache:
            if len(self.cache) >= self.cache_size:
                # 移除最早的缓存
                self.cache.pop(next(iter(self.cache)))
            self.cache[idx] = self.dataset[idx]
        return self.cache[idx]

    def __len__(self):
        return len(self.dataset)


def create_data_loaders(ct_dataset, mr_dataset, batch_size, num_workers=4):
    print(f"Original CT dataset size: {len(ct_dataset)}")
    print(f"Original MR dataset size: {len(mr_dataset)}")

    dataset_size = len(ct_dataset)
    indices = list(range(dataset_size))

    # 计算需要的重复次数，确保大于CT数据集大小
    mr_full_size = len(mr_dataset)
    repeat_times = math.ceil(dataset_size / mr_full_size)

    # 创建重复的MR数据集
    repeated_mr = RepeatDataset(mr_dataset, repeat_times)
    print(f"Repeated MR dataset size: {len(repeated_mr)}")

    # 划分数据集
    train_val_indices, test_indices = train_test_split(indices, test_size=0.15, random_state=42)
    train_indices, val_indices = train_test_split(train_val_indices, test_size=0.176, random_state=42)

    # 创建子集
    ct_train = Subset(ct_dataset, train_indices)
    ct_val = Subset(ct_dataset, val_indices)
    ct_test = Subset(ct_dataset, test_indices)

    # 为MR数据集创建对应长度的索引
    mr_train = Subset(repeated_mr, range(len(train_indices)))
    mr_val = Subset(repeated_mr, range(len(val_indices)))
    mr_test = Subset(repeated_mr, range(len(test_indices)))

    # 验证子集大小
    print("\nSubset sizes:")
    print(f"CT train: {len(ct_train)}, MR train: {len(mr_train)}")
    print(f"CT val: {len(ct_val)}, MR val: {len(mr_val)}")
    print(f"CT test: {len(ct_test)}, MR test: {len(mr_test)}")

    loader_kwargs = {
        'batch_size': batch_size,
        'num_workers': num_workers,
        'pin_memory': True,
        'prefetch_factor': 2,
        'persistent_workers': True
    }

    train_loader = DataLoaderX(
        CachedDataset(ct_train),
        shuffle=True,
        drop_last=True,
        **loader_kwargs
    )
    mr_train_loader = DataLoaderX(
        CachedDataset(mr_train),
        shuffle=True,
        drop_last=True,
        **loader_kwargs
    )
    val_loader = DataLoaderX(
        CachedDataset(ct_val),
        shuffle=False,
        **loader_kwargs
    )
    mr_val_loader = DataLoaderX(
        CachedDataset(mr_val),
        shuffle=False,
        **loader_kwargs
    )
    test_loader = DataLoaderX(
        CachedDataset(ct_test),
        shuffle=False,
        **loader_kwargs
    )
    mr_test_loader = DataLoaderX(
        CachedDataset(mr_test),
        shuffle=False,
        **loader_kwargs
    )

    return {
        'train': (train_loader, mr_train_loader),
        'val': (val_loader, mr_val_loader),
        'test': (test_loader, mr_test_loader),
        'indices': {
            'train': train_indices,
            'val': val_indices,
            'test': test_indices
        }
    }


def create_kfold_loaders(ct_dataset, mr_dataset, train_indices, batch_size, num_workers=4, n_splits=5):
    """
    Creates K-fold cross validation data loaders

    Args:
        ct_dataset: CT dataset
        mr_dataset: MR dataset
        train_indices: Indices for training data
        batch_size: Batch size for data loading
        num_workers: Number of worker processes
        n_splits: Number of folds

    Returns:
        list: List of dictionaries containing fold data loaders
    """
    kfold = KFold(n_splits=n_splits, shuffle=True, random_state=42)
    fold_loaders = []

    loader_kwargs = {
        'batch_size': batch_size,
        'num_workers': num_workers,
        'pin_memory': True,
        'prefetch_factor': 2,
        'persistent_workers': True
    }

    for fold, (train_fold_indices, val_fold_indices) in enumerate(kfold.split(train_indices)):
        # Get current fold indices
        current_train_indices = [train_indices[i] for i in train_fold_indices]
        current_val_indices = [train_indices[i] for i in val_fold_indices]

        # Create CT subsets
        ct_train = Subset(ct_dataset, current_train_indices)
        ct_val = Subset(ct_dataset, current_val_indices)

        # Create MR subsets matching the CT data size
        mr_train = Subset(mr_dataset, range(len(current_train_indices)))
        mr_val = Subset(mr_dataset, range(len(current_val_indices)))

        # Create loaders for this fold
        fold_loaders.append({
            'train': (
                DataLoaderX(CachedDataset(ct_train), shuffle=True, drop_last=True, **loader_kwargs),
                DataLoaderX(CachedDataset(mr_train), shuffle=True, drop_last=True, **loader_kwargs)
            ),
            'val': (
                DataLoaderX(CachedDataset(ct_val), shuffle=False, **loader_kwargs),
                DataLoaderX(CachedDataset(mr_val), shuffle=False, **loader_kwargs)
            )
        })

    return fold_loaders


class BinaryClassifier(nn.Module):
    def __init__(self, num_input_channels=512, num_class=2, base_channles=32):
        super(BinaryClassifier, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d((1, 1))

        self.fc1 = nn.Linear(num_input_channels, base_channles*8)
        self.bn1 = nn.BatchNorm1d(base_channles*8)
        self.dropout1 = nn.Dropout(0.2)

        self.fc2 = nn.Linear(base_channles*8, base_channles*4)
        self.bn2 = nn.BatchNorm1d(base_channles*4)
        self.dropout2 = nn.Dropout(0.2)

        self.fc3 = nn.Linear(base_channles*4, num_class)

        # 修改初始化策略
        init.kaiming_normal_(self.fc1.weight, mode='fan_out', nonlinearity='relu')
        init.kaiming_normal_(self.fc2.weight, mode='fan_out', nonlinearity='relu')
        init.xavier_uniform_(self.fc3.weight)  # 使用 xavier 初始化输出层

        # 初始化偏置
        if self.fc1.bias is not None:
            init.constant_(self.fc1.bias, 0)
        if self.fc2.bias is not None:
            init.constant_(self.fc2.bias, 0)
        if self.fc3.bias is not None:
            init.constant_(self.fc3.bias, 0)

    def forward(self, x):
        x = self.avg_pool(x)
        x = x.view(x.size(0), -1)

        x = self.fc1(x)
        x = F.relu(x)
        x = self.bn1(x)
        x = self.dropout1(x)

        x = self.fc2(x)
        x = F.relu(x)
        x = self.bn2(x)
        x = self.dropout2(x)

        x = self.fc3(x)
        return x

def create_binary_model(in_channels=512, n_class=2):
    binary_model = BinaryClassifier(num_input_channels=in_channels, num_class=n_class)

    return binary_model

def create_optimizer_and_scheduler(model, binary_model, args, train_loader):
    # 使用不同的学习率
    param_groups = [
        {'params': model.encoder.parameters(), 'lr': args.learning_rate * 1.1},
        {'params': model.decoder.parameters(), 'lr': args.learning_rate * 1.5},  # 提高decoder学习率
        {'params': model.vqvae.parameters(), 'lr': args.learning_rate * 1.2},
        {'params': binary_model.parameters(), 'lr': args.learning_rate * 0.7},
    ]

    # 修改基础学习率和优化器参数
    optimizer = optim.AdamW(
        param_groups,
        lr=args.learning_rate,
        weight_decay=args.weight_decay,
        betas=(0.9, 0.999),
        eps=1e-8,
        amsgrad=True
    )


    steps_per_epoch = len(train_loader)
    num_training_steps = args.num_epochs * steps_per_epoch

    def calculate_warmup_steps(total_steps):
        # 计算预热步数，保持较长的预热期但设置合理上限
        base_warmup = total_steps // 5  # 保持原有的1/5预热比例
        # 如果总步数较小，保持原有比例
        if total_steps < 10000:
            return base_warmup
        # 否则使用上限
        return min(base_warmup, 2000)  # 设置2000步的上限

    num_warmup_steps = calculate_warmup_steps(num_training_steps)

    def lr_lamba(current_step):
        if current_step < num_warmup_steps:
            # 线性预热
            return float(current_step) / float(max(1, num_warmup_steps))
        # 预热后的余弦退火
        progress = float(current_step - num_training_steps) / float(max(1, num_training_steps - num_warmup_steps))
        return max(0.1, 0.5 * (1.0 + math.cos(math.pi * progress)))

    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lamba)

    # 添加梯度裁剪
    for group in optimizer.param_groups:
        group['initial_lr'] = group['lr']
        group['max_grad_norm'] = 1.0  # 设置梯度裁剪阈值

    return optimizer, scheduler


def log_lr_stats(optimizer):
    # 用于监控每个参数组的学习率
    for i, group in enumerate(optimizer.param_groups):
        print(f"Parameter group {group['name']}: lr = {group['lr']:.6f}")


def train_model(model, criterion, optimizer, scheduler, dataload, mr_dataload, valid_dataloaders, mr_valid_dataloaders, binary_model, binary_criterion, fold_num, num_epochs=120):
    os.makedirs('./model', exist_ok=True)
    # 添加梯度裁剪
    grad_clip_value = 0.5
    # 添加混合精度训练,配置更保守的GradScaler
    scaler = GradScaler(
        init_scale=2**12,  # 提高初始scale
        growth_factor=1.5,  # 使用更保守的growth factor
        backoff_factor=0.7,
        growth_interval=500,
        enabled=True
    )


    train_losses = []
    valid_losses = []
    train_dice_scores = []
    valid_dice_scores = []

    best_validation_loss = float('inf')
    best_validation_dice = 0
    patience = 20  # 早停机制的耐心值
    patience_counter = 0
    best_model_state = None


    for epoch in range(1, num_epochs):
        print(f'Fold {fold_num}, Epoch {epoch}/{num_epochs}')
        print('Epoch {}/{}'.format(epoch, num_epochs))
        print('-' * 10)

        model.train()
        binary_model.train()

        # 初始化每个epoch的统计值
        epoch_loss = 0
        class_epoch_loss = 0
        epoch_dice = 0
        steps = 0
        correct_predictions = 0
        total_predictions = 0

        for batch_idx, ((x, y, class_y), (mr_x, mr_class_y)) in enumerate(zip(dataload, mr_dataload)):
            steps += 1

            inputs = x.to(device, non_blocking=True)
            labels = y.to(device, non_blocking=True)
            mr_inputs = mr_x.to(device, non_blocking=True)
            labels = torch.where(labels != 0, torch.tensor(1, dtype=labels.dtype).cuda(), labels)
            mr_class_y = mr_class_y.to(device, non_blocking=True)
            class_y = class_y.to(device, non_blocking=True)

            # 在forward pass之前检查输入数据
            if torch.isnan(inputs).any() or torch.isinf(inputs).any():
                print(f"Warning: Found NaN or Inf in batch {batch_idx}")
                continue

            # 使用混合精度训练
            with autocast():
                outputs_tuple, ct_encode_feature, mr_encode_feature, vq_loss, vq_loss2 = model(inputs, mr_inputs)
                if model.training:
                    outputs, deep_out1, deep_out2 = outputs_tuple
                    deep_loss1 = criterion(deep_out1, labels.float(), epoch, num_epochs)
                    deep_loss2 = criterion(deep_out2, labels.float(), epoch, num_epochs)
                else:
                    outputs = outputs_tuple

                # 计算分类损失: 修改为log_softmax + nll_Loss的组合
                ct_logits = binary_model(ct_encode_feature)
                ct_log_probs = F.log_softmax(ct_logits, dim=1)  # 转换为Log概率
                class_loss1 = F.nll_loss(ct_log_probs, class_y.long().squeeze())
                class_y_predict = ct_logits.detach().round()

                mr_logits = binary_model(mr_encode_feature)
                mr_log_probs = F.log_softmax(mr_logits, dim=1)
                class_loss2 = F.nll_loss(mr_log_probs, mr_class_y.long().squeeze())
                class_y_predict2 = mr_logits.detach().round()

                # 计算分类任务的准确率
                _, predicted_classes1 = torch.max(ct_logits, 1)
                correct_predictions += (predicted_classes1 == class_y.squeeze()).sum().item()
                total_predictions += class_y.size(0)

                _, predicted_classes2 = torch.max(mr_logits, 1)
                correct_predictions += (predicted_classes2 == mr_class_y.squeeze()).sum().item()
                total_predictions += mr_class_y.size(0)

                current_dice = dice_coefficient(outputs, labels)
                segmentation_loss = criterion(outputs, labels.float(), epoch, num_epochs)

                # total_loss = 5 * segmentation_loss + 0.5 * (class_loss1 + class_loss2) + 0.25 * (vq_loss + vq_loss2) + 0.2 * (deep_loss1 + deep_loss2)
                total_loss = 10 * segmentation_loss + 0.3 * (class_loss1 + class_loss2) + 0.2 * (vq_loss + vq_loss2) + 0.1 * (deep_loss1 + deep_loss2)

            # 检查损失值是否有效
            if not torch.isfinite(total_loss):
                print(f"Warning: not-finite loss detected: {total_loss}")
                continue

            # zero the parameter gradients
            optimizer.zero_grad()

            # 在backward之前检查梯度
            scaler.scale(total_loss).backward()
            scaler.unscale_(optimizer)


            # 在优化器步骤之前处理梯度
            def clip_gradients(model, max_grad_norm=0.5):
                for param in model.parameters():
                    # 将nan和inf替换为0
                    param.grad.nan_to_num_(nan=0.0, posinf=max_grad_norm, neginf=max_grad_norm)
                    # 裁剪梯度
                    torch.nn.utils.clip_grad_norm_([param], max_grad_norm)

            # 梯度裁剪
            clip_gradients(model, grad_clip_value)
            clip_gradients(binary_model, grad_clip_value)


            # 检查优化器步骤
            optimizer_step_success = scaler.step(optimizer)
            scheduler.step()
            scaler.update()


            # 记录损失
            epoch_loss += segmentation_loss.item()
            class_epoch_loss += (class_loss1.item() + class_loss2.item())
            epoch_dice += current_dice.item()

            # 定期清理缓存
            if batch_idx % 10 == 0:
                torch.cuda.empty_cache()


        # Average training loss and dice for the epoch
        avg_train_loss = epoch_loss / steps
        avg_class_loss = class_epoch_loss / steps
        avg_class_accuracy = correct_predictions / total_predictions
        avg_train_dice = epoch_dice / steps

        # 在epoch结束后记录损失
        train_losses.append(avg_train_loss)
        train_dice_scores.append(avg_train_dice)


        print(f"Epoch [{epoch}], Train Loss: {avg_train_loss:.3f}, Class Loss: {avg_class_loss:.3f}, Class Accuracy: {avg_class_accuracy:.4f}")
        print(f"Train Dice: {avg_train_dice:.3f}")



        # Validate the model at the end of the epoch
        model.eval()
        binary_model.eval()

        dice_val = 0
        val_loss = 0
        num_val_steps = 0

        with torch.no_grad():
                for (x, y, class_y), (mr_x, mr_class_y) in zip(valid_dataloaders, mr_valid_dataloaders):
                    x = x.type(torch.FloatTensor)
                    inputs = x.to(device, non_blocking=True)
                    labels = y.to(device, non_blocking=True)
                    mr_inputs = mr_x.to(device, non_blocking=True)
                    labels = torch.where(labels != 0, torch.tensor(1, dtype=labels.dtype).cuda(), labels)

                    outputs, _, _, _, _ = model(inputs, mr_inputs)

                    loss = criterion(outputs, labels, epoch, num_epochs)
                    dice = dice_coefficient(outputs, labels)

                    # 记录损失
                    val_loss += loss.detach().item()
                    dice_val += dice.item()
                    num_val_steps += 1

        # 计算平均loss和dice值
        avg_val_loss = val_loss / num_val_steps if num_val_steps > 0 else 0
        avg_dice_val = dice_val / num_val_steps if num_val_steps > 0 else 0

        valid_losses.append(avg_val_loss)
        valid_dice_scores.append(avg_dice_val)

        print(f"Epoch [{epoch}], Validation Loss： {avg_val_loss:.3f}, Validation Dice: {avg_dice_val:.3f}")


        # 绘制损失曲线
        if epoch % 10 == 0:
            plt.figure(figsize=(12, 4))

            plt.subplot(1, 2, 1)
            plt.plot(train_losses, label='Training Loss')
            plt.plot(valid_losses, label='Validation Loss')
            plt.title('Loss Curves')
            plt.xlabel('Epoch')
            plt.ylabel('Loss')
            plt.legend()

            plt.subplot(1, 2, 2)
            plt.plot(train_dice_scores, label='Training Dice')
            plt.plot(valid_dice_scores, label='Validation Dice')
            plt.title('Dice Score Curves')
            plt.xlabel('Epoch')
            plt.ylabel('Dice Score')
            plt.legend()

            plt.tight_layout()
            plt.savefig(f'./training_curves_epoch_{epoch}.png')
            plt.close()

        # 早停检查
        if avg_val_loss < best_validation_loss:
            model_save_path = f'./model/best_model_epoch_{epoch}.pth'

            if os.path.exists(model_save_path):
                os.remove(model_save_path)

            torch.save({
                'model_state_dict': model.state_dict(),
                'binary_model_state_dict': binary_model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scaler_state_dict': scaler.state_dict(),  # 保存scaler状态
                'epoch': epoch,
                'valid_loss': avg_val_loss,
                'valid_dice': avg_dice_val
            }, model_save_path)
            best_validation_loss = avg_val_loss
            patience_counter = 0
        else:
            patience_counter += 1

        if patience_counter >= patience:
            print(f"Early stopping triggered after {patience} epochs with no improvement.")
            break

        # 每个 epoch 结束时调用垃圾回收
        gc.collect()
        torch.cuda.empty_cache()

    return best_model_state, best_validation_loss

def evaluate_model(model, binary_model, ct_test_loader, mr_test_loader):
    model.eval()
    binary_model.eval()
    test_dice = 0
    test_steps = 0

    with torch.no_grad():
        for (x, y, _), (mr_x, _) in zip(ct_test_loader, mr_test_loader):
            x = x.to(device)
            y = y.to(device)
            mr_x = mr_x.to(device)
            y = torch.where(y != 0, torch.tensor(1, dtype=y.dtype).cuda(), y)

            outputs, _, _, _, _ = model(x, mr_x)

            # 使用固定阈值0.5计算Dice系数
            dice = dice_coefficient(outputs, y)

            test_dice += dice.item()
            test_steps += 1

    avg_dice = test_dice / test_steps

    return {'dice': avg_dice}


# 训练模型
def train(args):
    # 创建数据集
    data_dir = './chaos_data/CHAOS_Train_Sets'
    ct_dataset = CTImageDataset(data_dir, transform=data_transforms['Train_Sets'])
    mr_dataset = MRImageDataset(data_dir, transform=data_transforms['Train_Sets'])

    # 创建所有数据加载器
    data_loaders = create_data_loaders(
        ct_dataset,
        mr_dataset,
        batch_size=args.batch_size,
        num_workers=args.num_workers
    )

    # 打印数据集信息
    print("\nDataset splits:")
    total_size = len(ct_dataset)
    train_size = len(data_loaders['indices']['train'])
    val_size = len(data_loaders['indices']['val'])
    test_size = len(data_loaders['indices']['test'])

    print(f"Total dataset size: {total_size}")
    print(f"Training set size: {train_size} ({train_size / total_size * 100:.1f}%)")
    print(f"Validation set size: {val_size} ({val_size / total_size * 100:.1f}%)")
    print(f"Test set size: {test_size} ({test_size / total_size * 100:.1f}%)")

    # 保存测试集加载器，以供最终评估使用
    test_loaders = {
        'ct': data_loaders['test'][0],
        'mr': data_loaders['test'][1]
    }

    # 创建K-fold数据加载器
    fold_loaders = create_kfold_loaders(
        ct_dataset,
        mr_dataset,
        data_loaders['indices']['train'],
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        n_splits=args.n_folds
    )

    # 开始K-fold训练
    fold_results = []
    best_model_state = None
    best_binary_model_state = None
    best_fold_loss = float('inf')
    best_fold = -1

    for fold, fold_loader in enumerate(fold_loaders):
        print(f'\nTraining Fold {fold + 1}/{args.n_folds}')

        # 初始化模型
        model = Unet_vq_optimized(1, 1).to(device)
        binary_model = create_binary_model().to(device)

        # 初始化优化器和损失函数
        criterion = CombinedLoss()
        binary_criterion = nn.CrossEntropyLoss()

        train_loader = fold_loader['train'][0]

        optimizer, scheduler = create_optimizer_and_scheduler(model, binary_model, args, train_loader)

        # 训练当前fold
        fold_model_state, fold_val_loss = train_model(
            model,
            criterion,
            optimizer,
            scheduler,
            fold_loader['train'][0],  # CT train loader
            fold_loader['train'][1],  # MR train loader
            fold_loader['val'][0],  # CT val loader
            fold_loader['val'][1],  # MR val loader
            binary_model,
            binary_criterion,
            fold_num=fold + 1,
            num_epochs=args.num_epochs
        )

        # 保存fold结果
        fold_results.append({
            'fold': fold + 1,
            'val_loss': fold_val_loss,
            'model_state': fold_model_state
        })

        # 更新最佳模型
        if fold_val_loss < best_fold_loss:
            best_fold_loss = fold_val_loss
            best_fold = fold + 1
            best_model_state = copy.deepcopy(model.state_dict())
            best_binary_model_state = copy.deepcopy(binary_model.state_dict())
            # 保存最佳模型检查点
            torch.save({
                'model_state_dict': best_model_state,
                'binary_model_state_dict': best_binary_model_state,
                'fold': fold + 1,
                'val_loss': best_fold_loss
            }, f'best_model_fold_{best_fold}.pth')

        # 清理内存
        del model, binary_model, optimizer
        gc.collect()
        torch.cuda.empty_cache()

    # 打印交叉验证结果
    print("\nCross-validation results:")
    avg_val_loss = sum(r['val_loss'] for r in fold_results) / len(fold_results)
    for result in fold_results:
        print(f"Fold {result['fold']}: Validation Loss = {result['val_loss']:.4f}")
    print(f"\nAverage validation loss: {avg_val_loss:.4f}")
    print(f"Best fold: {best_fold} with validation loss: {best_fold_loss:.4f}")

    # 加载最佳模型，用于最终测试集评估
    print("\nLoading best model for test set evaluation..")
    final_model = Unet_vq_optimized(1, 1).to(device)
    final_binary_model = create_binary_model().to(device)

    final_model.load_state_dict(best_model_state)
    final_binary_model.load_state_dict(best_binary_model_state)

    # 在测试集上进行最终评估
    print("\nPerforming final evaluation on test set...")
    test_metrics = evaluate_model(
        final_model,
        final_binary_model,
        test_loaders['ct'],
        test_loaders['mr']
    )

    # 保存完整的评估结果
    results_summary = {
        'cross_validation': {
            'avg_val_loss': avg_val_loss,
            'best_fold': best_fold,
            'best_fold_loss': best_fold_loss
        },
        'test_set': {
            'dice_score': test_metrics['dice'],
        },
        'training_config': {
            'batch_size': args.batch_size,
            'num_epochs': args.num_epochs,
            'learning_rate': args.learning_rate,
            'n_folds': args.n_folds
        }
    }

    # 保存评估结果
    with open('final_evaluation_results.json', 'w') as f:
        json.dump(results_summary, f, indent=4)

    print("\nFinal Test Set Results:")
    print(f"Dice Score: {test_metrics['dice']:.4f}")
    print("\nComplete evaluation results have been saved to 'final_evaluation_results.json'")

    return final_model, final_binary_model, results_summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--batch_size', type=int, default=4)
    parser.add_argument('--num_workers', type=int, default=4)
    parser.add_argument('--n_folds', type=int, default=5)
    parser.add_argument('--num_epochs', type=int, default=140)
    parser.add_argument('--learning_rate', type=float, default=3e-4)
    parser.add_argument('--weight_decay', type=float, default=0.001)
    parser.add_argument('--gradient_accumulation_steps', type=int, default=4)
    args = parser.parse_args()

    # 启用CUDA优化
    torch.backends.cudnn.benchmark = True
    torch.backends.cuda.matmul.allow_tf32 = True

    train(args)

    