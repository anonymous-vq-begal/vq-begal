import torch
import torch.nn as nn
import torch.nn.functional as F


class VectorQuantizer_2(nn.Module):
    def __init__(self, num_embeddings, embedding_dim, commitment_cost):
        super(VectorQuantizer_2, self).__init__()

        # 增加embedding维度和数量来提高表达能力
        self.embedding_dim = embedding_dim
        self.num_embeddings = num_embeddings
        self.commitment_cost = commitment_cost

        # 使用更好的初始化方法
        self.embedding = nn.Embedding(num_embeddings, embedding_dim)
        nn.init.xavier_uniform_(self.embedding.weight)

        # EMA更新参数
        self.eps = 1e-5
        self.ema_decay = 0.99

        self.register_buffer('ema_cluster_size', torch.zeros(num_embeddings))
        self.register_buffer('ema_w', torch.zeros(num_embeddings, embedding_dim))
        self.register_buffer('ema_update_count', torch.ones(1))

    def forward(self, inputs):
        input_shape = inputs.shape
        flat_input = inputs.view(-1, self.embedding_dim)

        # 使用余弦相似度而不是欧氏距离，提高数值稳定性
        flat_input_normalized = F.normalize(flat_input, p=2, dim=1)
        embedding_normalized = F.normalize(self.embedding.weight, p=2, dim=1)

        # 计算距离
        distances = torch.cdist(flat_input_normalized, embedding_normalized, p=2)
        encoding_indices = torch.argmin(distances, dim=1)

        # Convert to one-hot
        encodings = F.one_hot(encoding_indices, self.num_embeddings).float()

        quantized = torch.matmul(encodings, self.embedding.weight)
        quantized = quantized.view(input_shape)

        # 计算损失
        q_latent_loss = F.mse_loss(quantized.detach(), inputs)
        e_latent_loss = F.mse_loss(quantized, inputs.detach())
        commitment_loss = self.commitment_cost * q_latent_loss

        loss = q_latent_loss + commitment_loss + e_latent_loss

        # EMA updates
        if self.training:
            self._ema_update(flat_input, encodings)

        # Straight through estimator
        quantized = inputs + (quantized - inputs).detach()

        return quantized, loss

    def _ema_update(self, flat_input, encodings):
        # EMA update for embeddings
        encoded_sum = torch.sum(encodings, dim=0)
        encoded_sum = encoded_sum.clamp(min=self.eps)

        self.ema_cluster_size.data.mul_(self.ema_decay).add_(
            encoded_sum * (1 - self.ema_decay)
        )

        dw = torch.matmul(encodings.t(), flat_input)
        self.ema_w.data.mul_(self.ema_decay).add_(dw * (1 - self.ema_decay))

        # Normalize embeddings
        n = self.ema_cluster_size.sum()
        cluster_size = (self.ema_cluster_size + self.eps) / (n + self.num_embeddings * self.eps) * n

        # Update embedding weights
        normalized_ema_w = self.ema_w / cluster_size.unsqueeze(1)
        self.embedding.weight.data.copy_(normalized_ema_w)


class EfficientBlock(nn.Module):
    def __init__(self, in_ch, out_ch, use_residual=True):
        super(EfficientBlock, self).__init__()
        self.use_residual = use_residual

        #  Depthwise separable convolution
        self.conv1 = nn.Sequential(
            nn.Conv2d(in_ch, in_ch, 3, padding=1, groups=in_ch),
            nn.Conv2d(in_ch, out_ch, 1),
            nn.GroupNorm(8, out_ch),
            nn.ReLU(inplace=True)
        )

        self.conv2 = nn.Sequential(
            nn.Conv2d(out_ch, out_ch, 3, padding=1, groups=out_ch),
            nn.Conv2d(out_ch, out_ch, 1),
            nn.GroupNorm(8, out_ch)
        )
        # Lightweight residual connection
        if use_residual and in_ch != out_ch:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_ch, out_ch, 1),
                nn.GroupNorm(8, out_ch)
            )
        else:
            self.shortcut = nn.Identity()

        self.relu = nn.ReLU(inplace=True)
        self.dropout = nn.Dropout2d(0.1)

    def forward(self, x):
        residual = self.shortcut(x) if self.use_residual else 0
        out = self.conv1(x)
        out = self.conv2(out)
        out = self.dropout(out + residual)
        return self.relu(out)


class LightWeightAttention(nn.Module):
    def __init__(self, channels):
        super(LightWeightAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channels, channels // 8),
            nn.ReLU(inplace=True),
            nn.Linear(channels // 8, channels),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y

class Encoder(nn.Module):
    def __init__(self, in_ch, base_channels=32):
        super(Encoder, self).__init__()

        self.initial_conv = nn.Sequential(
            nn.Conv2d(in_ch, base_channels, kernel_size=3, padding=1),
            nn.GroupNorm(8, base_channels),
            nn.ReLU(inplace=True)
        )

        # 使用base_channels作为基准，逐步增加
        self.enc1 = EfficientBlock(base_channels, base_channels)
        self.down1 = nn.Conv2d(base_channels, base_channels*2, kernel_size=4, stride=2, padding=1)
        self.enc2 = EfficientBlock(base_channels*2, base_channels*2)
        self.down2 = nn.Conv2d(base_channels*2, base_channels*4, kernel_size=4, stride=2, padding=1)
        self.enc3 = EfficientBlock(base_channels*4, base_channels*4)
        self.down3 = nn.Conv2d(base_channels*4, base_channels*8, kernel_size=4, stride=2, padding=1)
        self.enc4 = EfficientBlock(base_channels*8, base_channels*8)
        self.down4 = nn.Conv2d(base_channels*8, base_channels*16, kernel_size=4, stride=2, padding=1)

        self.bottleneck = nn.Sequential(
            EfficientBlock(base_channels*16, base_channels*16),
            LightWeightAttention(base_channels*16),
            nn.Dropout2d(0.1)
        )

    def forward(self, x):
        x = self.initial_conv(x)

        c1 = self.enc1(x)
        c2 = self.enc2(self.down1(c1))
        c3 = self.enc3(self.down2(c2))
        c4 = self.enc4(self.down3(c3))
        c5 = self.bottleneck(self.down4(c4))

        return c5, [c1, c2, c3, c4]

class DecoderBlock(nn.Module):
    def __init__(self, in_ch, out_ch, dropout=0.1):
        super(DecoderBlock, self).__init__()
        # 上采样
        self.up = nn.Sequential(
            nn.ConvTranspose2d(in_ch, out_ch, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(8, out_ch),
            nn.ReLU(inplace=True)
        )
        # 特征处理
        self.conv = nn.Sequential(
            EfficientBlock(out_ch*2, out_ch),
            nn.Dropout(dropout)
        )

    def forward(self, x , skip):
        x = self.up(x)
        x = torch.cat([x, skip], dim=1)
        return self.conv(x)

class Decoder(nn.Module):
    def __init__(self, out_ch, base_channels=32):
        super(Decoder, self).__init__()
        self.dec1 = DecoderBlock(512, base_channels * 8)
        self.dec2 = DecoderBlock(base_channels * 8, base_channels * 4)
        self.dec3 = DecoderBlock(base_channels * 4, base_channels * 2)
        self.dec4 = DecoderBlock(base_channels * 2, base_channels)
        self.final_conv = nn.Sequential(
            nn.Conv2d(base_channels, out_ch, 1),
            nn.GroupNorm(1, out_ch)
        )
        # Optional: Lightweight deep supervision (can be disabled)
        self.deep_sup = nn.ModuleList([
            nn.Conv2d(base_channels*8, out_ch, 1),
            nn.Conv2d(base_channels*4, out_ch, 1)
        ])

    def forward(self, c5, encoder_features):
        c1, c2, c3, c4 = encoder_features
        d4 = self.dec1(c5, c4)
        d3 = self.dec2(d4, c3)
        d2 = self.dec3(d3, c2)
        d1 = self.dec4(d2, c1)
        final_out = self.final_conv(d1)
        if self.training:
            deep_out1 = F.interpolate(self.deep_sup[0](d4), scale_factor=8)
            deep_out2 = F.interpolate(self.deep_sup[1](d3), scale_factor=4)
            return final_out, deep_out1, deep_out2
        return final_out


class Unet_vq_optimized(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(Unet_vq_optimized, self).__init__()
        # 增加embedding维度和数量
        num_embeddings = 1024
        embedding_dim = 512
        commitment_cost = 0.5

        self.encoder = Encoder(in_ch)
        self.decoder = Decoder(out_ch)

        # 改进特征适配层
        self.adaptor = nn.Sequential(
            nn.Conv2d(512, embedding_dim, 1),
            nn.GroupNorm(8, embedding_dim),
            nn.ReLU(inplace=True),
            LightWeightAttention(embedding_dim),
            nn.Dropout2d(0.1)
        )

        self.vqvae = VectorQuantizer_2(num_embeddings, embedding_dim, commitment_cost)

        # 改进特征融合机制
        self.fusion = nn.Sequential(
            nn.Conv2d(embedding_dim * 2, embedding_dim, 1),
            nn.GroupNorm(8, embedding_dim),
            nn.ReLU(inplace=True),
            LightWeightAttention(embedding_dim)
        )
        # 添加梯度裁剪参数
        self.grad_clip = 1.0

    def forward(self, x, mr_x):
        if torch.isnan(x).any() or torch.isnan(mr_x).any():
            raise ValueError("NaN detected in input tensors")

        # 应用梯度裁剪
        if self.training:
            torch.nn.utils.clip_grad_norm_(self.parameters(), self.grad_clip)

        c5, encoder_features = self.encoder(x)
        mr_c5, mr_encoder_features = self.encoder(mr_x)

        # 特征适配
        c5_adapted = self.adaptor(c5)
        mr_c5_adapted = self.adaptor(mr_c5)

        # VQ编码
        quantized_c5, vq_loss = self.vqvae(c5_adapted)
        quantized_mr_c5, vq_loss2 = self.vqvae(mr_c5_adapted)

        fused = self.fusion(torch.cat([quantized_c5, quantized_mr_c5], dim=1))

        if self.training:
            final_out, deep_out1, deep_out2 = self.decoder(fused, encoder_features)
            return (final_out, deep_out1, deep_out2), quantized_c5, quantized_mr_c5, vq_loss, vq_loss2
        else:
            out = self.decoder(fused, encoder_features)
            return out, quantized_c5, quantized_mr_c5, vq_loss, vq_loss2


class Unet_old(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(Unet_old, self).__init__()
        self.encoder = Encoder(in_ch)
        self.decoder = Decoder(out_ch)


    def forward(self, x, mr_x):
        c5, encoder_features = self.encoder(x)

        mr_c5, mr_encoder_features = self.encoder(mr_x)

        # Pass through the decoder
        alpha = 0.5
        fused = alpha * c5 + (1 - alpha) * mr_c5
        if self.training:
            final_out, deep_out1, deep_out2 = self.decoder(fused, encoder_features)
            return (final_out, deep_out1, deep_out2), c5, mr_c5
        else:
            out = self.decoder(fused, encoder_features)
            return out, c5, mr_c5


